import React, { useState } from 'react';
import { WorkOrder } from '../types/telemetry';
import { Wrench, CheckCircle, Clock, AlertTriangle, UserCheck, ShieldCheck, ArrowRight } from 'lucide-react';

interface WorkOrdersViewProps {
  workOrders: WorkOrder[];
  onDispatchOrder: (orderId: string, techName: string) => void;
  onResolveOrder: (orderId: string) => void;
}

export const WorkOrdersView: React.FC<WorkOrdersViewProps> = ({
  workOrders,
  onDispatchOrder,
  onResolveOrder,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'OPEN' | 'DISPATCHED' | 'RESOLVED'>('ALL');

  const filteredOrders = workOrders.filter(o => {
    if (filter === 'ALL') return true;
    return o.status === filter;
  });

  const openCount = workOrders.filter(o => o.status === 'OPEN').length;
  const dispatchedCount = workOrders.filter(o => o.status === 'DISPATCHED').length;
  const resolvedCount = workOrders.filter(o => o.status === 'RESOLVED').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Prescriptive Maintenance Work Orders
          </h1>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <span>Automated ML Threshold Dispatch</span>
            <span aria-hidden="true">·</span>
            <span>Estimated Unplanned Downtime Averted: 18.5 hrs</span>
            <span aria-hidden="true">·</span>
            <span>Condition-Based Maintenance (CBM)</span>
          </div>
        </div>

        {/* Status Counts */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <div className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5">
            <span className="text-slate-400">Open: </span>
            <span className="text-amber-400 font-bold tabular-nums">{openCount}</span>
          </div>
          <div className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5">
            <span className="text-slate-400">Dispatched: </span>
            <span className="text-cyan-400 font-bold tabular-nums">{dispatchedCount}</span>
          </div>
          <div className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5">
            <span className="text-slate-400">Resolved: </span>
            <span className="text-emerald-400 font-bold tabular-nums">{resolvedCount}</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800 max-w-fit">
        <button
          onClick={() => setFilter('ALL')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            filter === 'ALL' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Orders ({workOrders.length})
        </button>
        <button
          onClick={() => setFilter('OPEN')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            filter === 'OPEN' ? 'bg-slate-800 text-amber-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Open &amp; Pending ({openCount})
        </button>
        <button
          onClick={() => setFilter('DISPATCHED')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            filter === 'DISPATCHED' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Dispatched ({dispatchedCount})
        </button>
        <button
          onClick={() => setFilter('RESOLVED')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            filter === 'RESOLVED' ? 'bg-slate-800 text-emerald-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Resolved ({resolvedCount})
        </button>
      </div>

      {/* List of Orders */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-8 text-center text-slate-500">
            <ShieldCheck className="h-8 w-8 mx-auto mb-2 text-slate-600" />
            <p className="text-sm font-medium text-slate-400">No work orders in this category</p>
            <p className="text-xs text-slate-500 mt-1">All monitored industrial machinery operating within nominal parameters.</p>
          </div>
        ) : (
          filteredOrders.map(order => {
            const isResolved = order.status === 'RESOLVED';
            const isDispatched = order.status === 'DISPATCHED';

            let priorityBadge = 'text-amber-400 bg-amber-500/10 border-amber-500/30';
            if (order.priority === 'CRITICAL') priorityBadge = 'text-rose-400 bg-rose-500/10 border-rose-500/30';
            else if (order.priority === 'ROUTINE') priorityBadge = 'text-slate-300 bg-slate-800 border-slate-700';

            return (
              <div
                key={order.id}
                className={`rounded-xl border bg-slate-900/80 p-5 transition-all ${
                  isResolved
                    ? 'border-slate-800/60 opacity-80'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Header: Unboxed metadata */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3 mb-3">
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="font-bold text-cyan-400">{order.work_order_num}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-300">{order.machine_tag}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-400">{order.machine_name}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 text-xs font-medium rounded border ${priorityBadge}`}>
                      {order.priority}
                    </span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded border font-mono ${
                      isResolved
                        ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                        : isDispatched
                        ? 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
                        : 'text-amber-400 bg-amber-500/10 border-amber-500/30'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                </div>

                {/* Body Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="md:col-span-2 space-y-2">
                    <div>
                      <span className="text-slate-500 font-mono text-[11px] block">TARGET COMPONENT</span>
                      <span className="text-sm font-semibold text-white">{order.target_component}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 font-mono text-[11px] block">RECOMMENDED PROCEDURE</span>
                      <p className="text-slate-300 leading-relaxed mt-0.5">{order.recommended_action}</p>
                    </div>

                    <div>
                      <span className="text-slate-500 font-mono text-[11px] block">REQUIRED SPARE PARTS</span>
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {order.parts_required.map((part, idx) => (
                          <span
                            key={idx}
                            className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-300 text-[11px] font-mono"
                          >
                            {part}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Quantitative Metrics & Actions */}
                  <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3 space-y-3 flex flex-col justify-between">
                    <div className="space-y-2 font-mono text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Predicted RUL:</span>
                        <span className="text-cyan-300 font-bold tabular-nums">{order.predicted_rul_hours} hrs</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Est. Downtime:</span>
                        <span className="text-white tabular-nums">{order.estimated_downtime_hours} hrs</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Technician:</span>
                        <span className="text-slate-300 truncate max-w-[120px]">
                          {order.assigned_technician || 'Unassigned'}
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2">
                      {!isResolved && !isDispatched && (
                        <button
                          onClick={() => onDispatchOrder(order.id, 'Marcus Vance (Reliability Lead)')}
                          className="flex-1 py-1.5 px-3 rounded-lg bg-cyan-400 text-slate-950 font-semibold text-xs hover:bg-cyan-300 transition-colors cursor-pointer text-center"
                        >
                          Dispatch Crew
                        </button>
                      )}

                      {!isResolved && isDispatched && (
                        <button
                          onClick={() => onResolveOrder(order.id)}
                          className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-500 text-slate-950 font-semibold text-xs hover:bg-emerald-400 transition-colors cursor-pointer text-center"
                        >
                          Mark Completed
                        </button>
                      )}

                      {isResolved && (
                        <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                          <CheckCircle className="h-4 w-4" />
                          <span>Maintenance Resolved</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
