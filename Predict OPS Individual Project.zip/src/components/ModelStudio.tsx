import React, { useState } from 'react';
import { ModelMetrics } from '../types/telemetry';
import { trainModel } from '../services/apiService';
import { Play, RotateCw, CheckCircle2, Sliders, Cpu, GitBranch, Layers } from 'lucide-react';

interface ModelStudioProps {
  metrics: ModelMetrics;
  onMetricsUpdate: (newMetrics: ModelMetrics) => void;
}

export const ModelStudio: React.FC<ModelStudioProps> = ({ metrics, onMetricsUpdate }) => {
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(0);
  const [trainingLog, setTrainingLog] = useState<string>('');
  const [estimators, setEstimators] = useState(120);
  const [learningRate, setLearningRate] = useState(0.08);
  const [maxDepth, setMaxDepth] = useState(5);
  const [testSplit, setTestSplit] = useState(0.2);

  const handleStartTraining = async () => {
    setIsTraining(true);
    setTrainingProgress(0);
    setTrainingLog('Initializing XGBoost & Scikit-Learn training pipeline...');

    try {
      const updated = await trainModel({
        estimators,
        learning_rate: learningRate,
        max_depth: maxDepth,
        test_split: testSplit,
        onProgress: (p, msg) => {
          setTrainingProgress(p);
          setTrainingLog(msg);
        },
      });
      onMetricsUpdate(updated);
    } finally {
      setIsTraining(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Machine Learning Pipeline & Model Studio
          </h1>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <span>Model: {metrics.version}</span>
            <span aria-hidden="true">·</span>
            <span>Architecture: {metrics.algorithm}</span>
            <span aria-hidden="true">·</span>
            <span>Training Corpus: {metrics.dataset_size.toLocaleString()} records</span>
          </div>
        </div>

        <button
          onClick={handleStartTraining}
          disabled={isTraining}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg text-slate-950 transition-all cursor-pointer ${
            isTraining
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-cyan-400 hover:bg-cyan-300 shadow-md shadow-cyan-950'
          }`}
        >
          {isTraining ? <RotateCw className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
          <span>{isTraining ? 'Training in Progress...' : 'Re-Train Pipeline'}</span>
        </button>
      </div>

      {/* Pipeline Architecture Schematic Banner */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 overflow-x-auto">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-3">
          End-to-End Machine Learning Architecture
        </h4>
        <div className="flex items-center gap-2 min-w-[700px] text-xs">
          {/* Step 1 */}
          <div className="flex-1 rounded-lg bg-slate-950/80 border border-slate-800 p-3">
            <div className="flex items-center gap-2 text-cyan-400 mb-1 font-semibold">
              <Cpu className="h-4 w-4" />
              <span>1. Ingestion</span>
            </div>
            <p className="text-[11px] text-slate-400">
              6-Channel Telemetry (Vibration, Temp, Pressure, Speed, Torque, Acoustic)
            </p>
          </div>

          <span className="text-slate-600 font-bold">→</span>

          {/* Step 2 */}
          <div className="flex-1 rounded-lg bg-slate-950/80 border border-slate-800 p-3">
            <div className="flex items-center gap-2 text-indigo-400 mb-1 font-semibold">
              <Layers className="h-4 w-4" />
              <span>2. Engineering</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Crest Factor, Kurtosis excess, Thermal Delta, Power kW &amp; rolling variance
            </p>
          </div>

          <span className="text-slate-600 font-bold">→</span>

          {/* Step 3 */}
          <div className="flex-1 rounded-lg bg-slate-950/80 border border-slate-800 p-3">
            <div className="flex items-center gap-2 text-amber-400 mb-1 font-semibold">
              <GitBranch className="h-4 w-4" />
              <span>3. XGBoost Ensemble</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {estimators} Boosted Trees (depth={maxDepth}, lr={learningRate})
            </p>
          </div>

          <span className="text-slate-600 font-bold">→</span>

          {/* Step 4 */}
          <div className="flex-1 rounded-lg bg-slate-950/80 border border-slate-800 p-3">
            <div className="flex items-center gap-2 text-emerald-400 mb-1 font-semibold">
              <CheckCircle2 className="h-4 w-4" />
              <span>4. FastAPI Inference</span>
            </div>
            <p className="text-[11px] text-slate-400">
              POST /api/v1/predict with sub-5ms latency and RUL prognostic curve
            </p>
          </div>
        </div>
      </div>

      {/* Training In-Flight Progress Modal / Banner */}
      {isTraining && (
        <div className="rounded-xl border border-cyan-500/40 bg-cyan-950/20 p-4 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-cyan-300">Model Training in Progress</span>
            <span className="font-mono text-cyan-400 tabular-nums">{trainingProgress}%</span>
          </div>
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-cyan-400 rounded-full transition-all duration-300"
              style={{ width: `${trainingProgress}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-300 font-mono">{trainingLog}</p>
        </div>
      )}

      {/* Model Performance Top Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-3">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Accuracy</span>
          <span className="text-xl font-bold font-mono tabular-nums text-white">
            {(metrics.accuracy * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-emerald-400 block mt-0.5">Holdout 20%</span>
        </div>

        <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-3">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">ROC-AUC</span>
          <span className="text-xl font-bold font-mono tabular-nums text-cyan-300">
            {metrics.roc_auc.toFixed(3)}
          </span>
          <span className="text-[10px] text-slate-500 block mt-0.5">High discriminative power</span>
        </div>

        <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-3">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Precision</span>
          <span className="text-xl font-bold font-mono tabular-nums text-white">
            {(metrics.precision * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Low false alarm rate</span>
        </div>

        <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-3">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Recall</span>
          <span className="text-xl font-bold font-mono tabular-nums text-white">
            {(metrics.recall * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Catches 94.8% faults</span>
        </div>

        <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-3">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">F1-Score</span>
          <span className="text-xl font-bold font-mono tabular-nums text-white">
            {(metrics.f1_score * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Harmonic balance</span>
        </div>

        <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-3">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Inference Time</span>
          <span className="text-xl font-bold font-mono tabular-nums text-emerald-400">
            {metrics.inference_latency_avg_ms.toFixed(2)} ms
          </span>
          <span className="text-[10px] text-slate-500 block mt-0.5">Real-time edge ready</span>
        </div>
      </div>

      {/* Main Analysis Section: Confusion Matrix & ROC Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Confusion Matrix Heatmap */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Multi-Class Confusion Matrix (Validation Holdout)
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                Rows: Ground Truth · Columns: Model Predicted
              </span>
            </div>
            <span className="text-xs font-mono text-cyan-400">Total: 2,514 validation rows</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse text-xs font-mono">
              <thead>
                <tr>
                  <th className="p-2 text-left text-slate-500 font-sans text-[11px]">True \ Pred</th>
                  {metrics.confusion_matrix.classes.map((cls, i) => (
                    <th key={i} className="p-2 text-slate-300 font-semibold text-[11px] truncate max-w-[70px]">
                      {cls}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {metrics.confusion_matrix.matrix.map((row, rIdx) => {
                  const trueClass = metrics.confusion_matrix.classes[rIdx];
                  const rowSum = row.reduce((a, b) => a + b, 0);

                  return (
                    <tr key={rIdx} className="border-t border-slate-800/60">
                      <td className="p-2 text-left font-sans text-slate-400 font-medium text-[11px]">
                        {trueClass}
                      </td>
                      {row.map((val, cIdx) => {
                        const isDiagonal = rIdx === cIdx;
                        const percentage = ((val / rowSum) * 100).toFixed(0);

                        return (
                          <td
                            key={cIdx}
                            className={`p-2 transition-colors tabular-nums ${
                              isDiagonal
                                ? 'bg-cyan-500/20 text-cyan-200 font-bold border border-cyan-500/30'
                                : val > 0
                                ? 'bg-slate-950/60 text-slate-400'
                                : 'text-slate-600'
                            }`}
                          >
                            <div>{val}</div>
                            {isDiagonal && (
                              <div className="text-[9px] text-cyan-400/80 font-normal">{percentage}%</div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* ROC Curve Graph */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Receiver Operating Characteristic (ROC Curve)
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                True Positive Rate vs. False Positive Rate (AUC = {metrics.roc_auc.toFixed(3)})
              </span>
            </div>
            <span className="text-xs font-mono text-emerald-400">Sensitivity: 95.2%</span>
          </div>

          <div className="relative w-full aspect-[16/10] bg-slate-950 rounded-lg p-3 border border-slate-800">
            <svg viewBox="0 0 300 180" className="w-full h-full">
              {/* Axes and Reference diagonal */}
              <line x1="30" y1="150" x2="280" y2="150" stroke="#334155" strokeWidth="1" />
              <line x1="30" y1="20" x2="30" y2="150" stroke="#334155" strokeWidth="1" />
              <line x1="30" y1="150" x2="280" y2="20" stroke="#475569" strokeWidth="1" strokeDasharray="3 3" />

              {/* ROC Points Polyline */}
              <polyline
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2.5"
                strokeLinecap="round"
                points={metrics.roc_curve.fpr
                  .map((fpr, i) => {
                    const tpr = metrics.roc_curve.tpr[i];
                    const x = 30 + fpr * 250;
                    const y = 150 - tpr * 130;
                    return `${x.toFixed(1)},${y.toFixed(1)}`;
                  })
                  .join(' ')}
              />

              {/* Data points */}
              {metrics.roc_curve.fpr.map((fpr, i) => {
                const tpr = metrics.roc_curve.tpr[i];
                const x = 30 + fpr * 250;
                const y = 150 - tpr * 130;
                return (
                  <circle
                    key={i}
                    cx={x}
                    cy={y}
                    r="3.5"
                    fill="#06b6d4"
                    stroke="#0f172a"
                    strokeWidth="1.5"
                  />
                );
              })}

              <text x="35" y="32" fill="#06b6d4" fontSize="9" fontFamily="monospace">AUC = {metrics.roc_auc.toFixed(3)}</text>
              <text x="150" y="172" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">False Positive Rate (1 - Specificity)</text>
              <text x="18" y="85" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace" transform="rotate(-90 18 85)">True Positive Rate</text>
            </svg>
          </div>
        </div>
      </div>

      {/* Feature Importance & Hyperparameter Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Feature Importance Bar Ranking */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Global Feature Importance (XGBoost Gain)
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                Relative information gain contribution to tree splits
              </span>
            </div>
          </div>

          <div className="space-y-3">
            {metrics.feature_importance.map((f, i) => (
              <div key={f.feature} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-500 text-[11px]">0{i + 1}.</span>
                    <span className="font-medium text-slate-300">{f.label}</span>
                  </div>
                  <span className="font-mono font-semibold text-cyan-300 tabular-nums">
                    {(f.importance * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-cyan-500 rounded-full transition-all duration-300"
                    style={{ width: `${(f.importance / 0.3) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hyperparameter Tuning Studio */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Hyperparameter Calibration & Retraining
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                Tune GBDT model parameters before pushing weights to production
              </span>
            </div>
            <Sliders className="h-4 w-4 text-cyan-400" />
          </div>

          <div className="space-y-4 text-xs">
            {/* Estimators Slider */}
            <div>
              <div className="flex justify-between mb-1.5">
                <span className="text-slate-300 font-medium">Number of Estimators (n_trees):</span>
                <span className="font-mono text-cyan-300 font-semibold tabular-nums">{estimators} trees</span>
              </div>
              <input
                type="range"
                min="50"
                max="250"
                step="10"
                value={estimators}
                onChange={(e) => setEstimators(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Learning Rate */}
            <div>
              <div className="flex justify-between mb-1.5">
                <span className="text-slate-300 font-medium">Learning Rate (eta):</span>
                <span className="font-mono text-cyan-300 font-semibold tabular-nums">{learningRate}</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="0.2"
                step="0.01"
                value={learningRate}
                onChange={(e) => setLearningRate(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Max Depth */}
            <div>
              <div className="flex justify-between mb-1.5">
                <span className="text-slate-300 font-medium">Maximum Tree Depth (max_depth):</span>
                <span className="font-mono text-cyan-300 font-semibold tabular-nums">{maxDepth}</span>
              </div>
              <input
                type="range"
                min="3"
                max="9"
                step="1"
                value={maxDepth}
                onChange={(e) => setMaxDepth(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Train / Test Split */}
            <div>
              <div className="flex justify-between mb-1.5">
                <span className="text-slate-300 font-medium">Test Split Ratio:</span>
                <span className="font-mono text-cyan-300 font-semibold tabular-nums">{(testSplit * 100).toFixed(0)}% Holdout</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="0.35"
                step="0.05"
                value={testSplit}
                onChange={(e) => setTestSplit(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="pt-2">
              <button
                onClick={handleStartTraining}
                disabled={isTraining}
                className="w-full py-2 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer border border-slate-700"
              >
                <Play className="h-3.5 w-3.5 text-cyan-400" />
                <span>Execute Training Run with Above Hyperparameters</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
