import React, { useState } from 'react';
import { MachineAsset } from '../types/telemetry';
import { MachineVisualSchematic } from './MachineVisualSchematic';
import { Activity, AlertTriangle, CheckCircle, Clock, ChevronRight, Sliders, ShieldCheck } from 'lucide-react';

interface FleetOverviewProps {
  machines: MachineAsset[];
  selectedMachineId: string;
  onSelectMachine: (id: string) => void;
  onInjectFault: (machineId: string, faultType: string) => void;
  onResetFault: (machineId: string) => void;
  onOpenApiForMachine: (machine: MachineAsset) => void;
  onNavigateToTelemetry: (machineId: string) => void;
  onNavigateToDataEntry: (machineId: string) => void;
}

export const FleetOverview: React.FC<FleetOverviewProps> = ({
  machines,
  selectedMachineId,
  onSelectMachine,
  onInjectFault,
  onResetFault,
  onOpenApiForMachine,
  onNavigateToTelemetry,
  onNavigateToDataEntry,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'CRITICAL_WARNING' | 'PUMP' | 'SPINDLE'>('ALL');

  const filteredMachines = machines.filter(m => {
    if (filter === 'CRITICAL_WARNING') return m.status === 'WARNING' || m.status === 'CRITICAL';
    if (filter === 'PUMP') return m.type === 'Centrifugal Pump';
    if (filter === 'SPINDLE') return m.type === 'CNC Spindle';
    return true;
  });

  const selectedMachine = machines.find(m => m.id === selectedMachineId) || machines[0];

  // Fleet stats
  const avgHealth = Math.round(machines.reduce((acc, m) => acc + m.health_index, 0) / machines.length);
  const criticalCount = machines.filter(m => m.status === 'CRITICAL').length;
  const warningCount = machines.filter(m => m.status === 'WARNING' || m.status === 'MONITOR').length;

  return (
    <div className="space-y-6">
      {/* Editorial Header & Fleet Status Bar */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Industrial Fleet Digital Twins
          </h1>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <span>ISO 10816 Telemetry Stream Active</span>
            <span aria-hidden="true">·</span>
            <span>4 Connected Industrial Workcells</span>
            <span aria-hidden="true">·</span>
            <span>Real-time XGBoost ML Inference</span>
          </div>
        </div>

        {/* Top Quantitative Rigor KPI Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
          <div className="rounded-lg bg-slate-900/90 border border-slate-800 px-3 py-2">
            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block">Fleet Health</span>
            <span className="text-lg font-bold text-white font-mono tabular-nums">{avgHealth}%</span>
            <span className="text-[10px] text-emerald-400 ml-1">Nominal</span>
          </div>

          <div className="rounded-lg bg-slate-900/90 border border-slate-800 px-3 py-2">
            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block">At-Risk Assets</span>
            <span className="text-lg font-bold font-mono tabular-nums text-amber-400">{warningCount + criticalCount}</span>
            <span className="text-[10px] text-slate-500 ml-1">/ {machines.length} Total</span>
          </div>

          <div className="rounded-lg bg-slate-900/90 border border-slate-800 px-3 py-2">
            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block">Inference Latency</span>
            <span className="text-lg font-bold text-cyan-400 font-mono tabular-nums">3.2 ms</span>
            <span className="text-[10px] text-slate-500 ml-1">p99</span>
          </div>

          <div className="rounded-lg bg-slate-900/90 border border-slate-800 px-3 py-2">
            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block">Model Precision</span>
            <span className="text-lg font-bold text-emerald-400 font-mono tabular-nums">96.8%</span>
            <span className="text-[10px] text-slate-500 ml-1">AUC 0.984</span>
          </div>
        </div>
      </div>

      {/* Filter Segmented Control */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
          <button
            onClick={() => setFilter('ALL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filter === 'ALL' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Workcells ({machines.length})
          </button>
          <button
            onClick={() => setFilter('CRITICAL_WARNING')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filter === 'CRITICAL_WARNING' ? 'bg-slate-800 text-amber-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Warnings & Critical ({warningCount + criticalCount})
          </button>
          <button
            onClick={() => setFilter('PUMP')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filter === 'PUMP' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Pumps
          </button>
          <button
            onClick={() => setFilter('SPINDLE')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filter === 'SPINDLE' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Spindles
          </button>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigateToDataEntry(selectedMachineId)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-cyan-950/40 text-cyan-300 border border-cyan-800/40 hover:bg-cyan-900/40 transition-colors cursor-pointer"
          >
            <span>+ Enter Telemetry / Ingest</span>
          </button>
          <div className="text-xs text-slate-400">
            Showing <span className="text-white font-mono tabular-nums">{filteredMachines.length}</span> industrial assets
          </div>
        </div>
      </div>

      {/* Grid of Industrial Asset Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-4">
        {filteredMachines.map(machine => {
          const prediction = machine.latest_prediction;
          const isSelected = machine.id === selectedMachineId;

          // Status colors
          let statusBadgeColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
          let statusText = 'Nominal Condition';
          if (machine.status === 'CRITICAL') {
            statusBadgeColor = 'text-rose-400 border-rose-500/30 bg-rose-500/10';
            statusText = 'Critical Risk';
          } else if (machine.status === 'WARNING') {
            statusBadgeColor = 'text-amber-400 border-amber-500/30 bg-amber-500/10';
            statusText = 'Early Warning';
          } else if (machine.status === 'MONITOR') {
            statusBadgeColor = 'text-sky-400 border-sky-500/30 bg-sky-500/10';
            statusText = 'Active Monitoring';
          }

          return (
            <div
              key={machine.id}
              onClick={() => onSelectMachine(machine.id)}
              className={`group flex flex-col rounded-xl border bg-slate-900/60 p-4 transition-all cursor-pointer ${
                isSelected
                  ? 'border-cyan-500/60 shadow-lg shadow-cyan-950/30 bg-slate-900/90'
                  : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
              }`}
            >
              {/* Header: Unboxed metadata, no static pill sandwiches */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-1 font-mono">
                    <span className="font-semibold text-cyan-400">{machine.id}</span>
                    <span aria-hidden="true">·</span>
                    <span>{machine.tag}</span>
                    <span aria-hidden="true">·</span>
                    <span>{machine.location}</span>
                  </div>
                  <h3 className="text-base font-semibold text-white group-hover:text-cyan-300 transition-colors">
                    {machine.name}
                  </h3>
                </div>

                <div className={`px-2.5 py-1 text-xs font-medium rounded border ${statusBadgeColor}`}>
                  {statusText}
                </div>
              </div>

              {/* Technical Schematic Drawing */}
              <div className="mb-4">
                <MachineVisualSchematic machine={machine} />
              </div>

              {/* ML Prediction Highlights */}
              {prediction && (
                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3 mb-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Predicted State:</span>
                    <span className="font-semibold text-white">{prediction.failure_mode_label}</span>
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Failure Probability:</span>
                    <span className={`font-mono font-semibold tabular-nums ${
                      prediction.failure_probability > 0.4 ? 'text-amber-400' : 'text-emerald-400'
                    }`}>
                      {(prediction.failure_probability * 100).toFixed(1)}%
                    </span>
                  </div>

                  {/* Health Index Progress Bar */}
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-slate-400">Health Index</span>
                      <span className="font-mono tabular-nums text-white">{machine.health_index}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 rounded-full ${
                          machine.health_index > 75
                            ? 'bg-emerald-500'
                            : machine.health_index > 45
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${machine.health_index}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-900">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Clock className="h-3 w-3 text-slate-500" />
                      Estimated RUL:
                    </span>
                    <span className="font-mono font-semibold text-cyan-300 tabular-nums">
                      {prediction.remaining_useful_life_hours} hrs (~{(prediction.remaining_useful_life_hours / 24).toFixed(0)} days)
                    </span>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="mt-auto flex items-center justify-between pt-2 border-t border-slate-800/60 gap-2">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigateToDataEntry(machine.id);
                    }}
                    className="px-2.5 py-1 text-xs text-amber-300 hover:text-amber-200 bg-amber-950/30 hover:bg-amber-900/40 border border-amber-800/40 rounded transition-colors cursor-pointer"
                  >
                    Enter Data
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigateToTelemetry(machine.id);
                    }}
                    className="px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
                  >
                    Oscillogram
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenApiForMachine(machine);
                    }}
                    className="px-2.5 py-1 text-xs text-cyan-400 hover:text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-800/40 rounded transition-colors cursor-pointer"
                  >
                    API Payload
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  {machine.active_fault ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onResetFault(machine.id);
                      }}
                      className="px-2.5 py-1 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 rounded hover:bg-emerald-900/40 transition-colors cursor-pointer"
                    >
                      Reset Fault
                    </button>
                  ) : (
                    <div className="flex gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onInjectFault(machine.id, 'bearing');
                        }}
                        className="px-2 py-0.5 text-[11px] text-amber-300 bg-amber-950/30 border border-amber-800/30 rounded hover:bg-amber-900/40 transition-colors cursor-pointer"
                        title="Simulate bearing raceway spalling defect"
                      >
                        +Bearing Fault
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onInjectFault(machine.id, 'thermal');
                        }}
                        className="px-2 py-0.5 text-[11px] text-rose-300 bg-rose-950/30 border border-rose-800/30 rounded hover:bg-rose-900/40 transition-colors cursor-pointer"
                        title="Simulate thermal cooling loss"
                      >
                        +Heat Fault
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Machine Detail Inspection Panel */}
      {selectedMachine && selectedMachine.latest_prediction && (
        <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 mt-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mb-1">
                <span>DEEP DIVE TELEMETRY</span>
                <span aria-hidden="true">·</span>
                <span>{selectedMachine.id}</span>
                <span aria-hidden="true">·</span>
                <span>{selectedMachine.installed_date}</span>
              </div>
              <h2 className="text-lg font-bold text-white">
                {selectedMachine.name} — Machine Learning Diagnosis
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Total Operating Hours:</span>
              <span className="text-sm font-mono font-semibold text-white tabular-nums">
                {selectedMachine.operating_hours.toLocaleString()} hrs
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-5">
            {/* Column 1: Feature Contributions (SHAP-style explainability) */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                  Feature Attribution (SHAP Risk Drivers)
                </h4>
                <span className="text-xs text-slate-500">Relative impact on failure probability</span>
              </div>

              <div className="space-y-3">
                {selectedMachine.latest_prediction.feature_contributions.map((feat) => (
                  <div key={feat.feature} className="rounded-lg bg-slate-950/60 border border-slate-800/60 p-2.5">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-slate-200">{feat.label}</span>
                        <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                          {feat.measured_value}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 font-mono text-xs tabular-nums">
                        <span className="text-slate-500">ref: {feat.reference_nominal}</span>
                        <span className={`font-semibold ${
                          feat.direction === 'increases_risk' ? 'text-rose-400' : 'text-slate-400'
                        }`}>
                          {feat.contribution}%
                        </span>
                      </div>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800/80 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          feat.direction === 'increases_risk' ? 'bg-rose-500' : 'bg-cyan-500'
                        }`}
                        style={{ width: `${feat.contribution}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 2: Prescriptive Actions & Subsystem Health */}
            <div className="space-y-5">
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-3">
                  Subsystem Health Degradation
                </h4>
                <div className="space-y-2 text-xs">
                  {Object.entries(selectedMachine.component_health).map(([comp, val]) => (
                    <div key={comp} className="flex items-center justify-between bg-slate-950/40 p-2 rounded border border-slate-800/40">
                      <span className="capitalize text-slate-300">{comp.replace('_', ' ')}</span>
                      <div className="flex items-center gap-2 font-mono tabular-nums">
                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${val > 70 ? 'bg-emerald-500' : val > 40 ? 'bg-amber-500' : 'bg-rose-500'}`}
                            style={{ width: `${val}%` }} 
                          />
                        </div>
                        <span className={val > 70 ? 'text-emerald-400' : val > 40 ? 'text-amber-400' : 'text-rose-400'}>
                          {val}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-2">
                  Prescriptive Recommendations
                </h4>
                <div className="space-y-2">
                  {selectedMachine.latest_prediction.prescriptive_actions.map((act, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-300 bg-slate-950/60 p-2 rounded border border-slate-800/60">
                      <ChevronRight className="h-3.5 w-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{act}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
