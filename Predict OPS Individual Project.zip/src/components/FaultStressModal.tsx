import React from 'react';
import { MachineAsset } from '../types/telemetry';
import { X, AlertTriangle, Flame, Droplets, Zap, RotateCcw } from 'lucide-react';

interface FaultStressModalProps {
  isOpen: boolean;
  onClose: () => void;
  machines: MachineAsset[];
  selectedMachineId: string;
  setSelectedMachineId: (id: string) => void;
  onInjectFault: (machineId: string, faultType: string) => void;
  onResetFault: (machineId: string) => void;
}

export const FaultStressModal: React.FC<FaultStressModalProps> = ({
  isOpen,
  onClose,
  machines,
  selectedMachineId,
  setSelectedMachineId,
  onInjectFault,
  onResetFault,
}) => {
  if (!isOpen) return null;

  const currentMachine = machines.find(m => m.id === selectedMachineId) || machines[0];

  const handleInjectAndClose = (type: string) => {
    onInjectFault(currentMachine.id, type);
    onClose();
  };

  const handleResetAndClose = () => {
    onResetFault(currentMachine.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white">Simulate Industrial Fault Stress</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Inject telemetry anomalies to observe real-time ML pipeline classification and RUL decay.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Machine Picker */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1.5">
            Select Target Industrial Asset:
          </label>
          <select
            value={selectedMachineId}
            onChange={(e) => setSelectedMachineId(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
          >
            {machines.map(m => (
              <option key={m.id} value={m.id}>
                {m.id} — {m.name} ({m.type})
              </option>
            ))}
          </select>
        </div>

        {/* Fault Presets */}
        <div className="space-y-2.5">
          <label className="block text-xs font-medium text-slate-400 font-mono uppercase">
            Select Anomaly Mode:
          </label>

          <button
            onClick={() => handleInjectAndClose('bearing')}
            className="w-full p-3 text-left rounded-lg bg-slate-950/60 border border-amber-900/40 hover:border-amber-600/60 hover:bg-amber-950/20 transition-all flex items-start gap-3 cursor-pointer group"
          >
            <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <div>
              <div className="text-xs font-semibold text-white">Bearing Raceway Spalling Defect</div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Spikes vibration RMS to 4.8 mm/s, Kurtosis to 6.8 (impulsive shocks), and acoustic emission to 72 dB.
              </p>
            </div>
          </button>

          <button
            onClick={() => handleInjectAndClose('thermal')}
            className="w-full p-3 text-left rounded-lg bg-slate-950/60 border border-rose-900/40 hover:border-rose-600/60 hover:bg-rose-950/20 transition-all flex items-start gap-3 cursor-pointer group"
          >
            <Flame className="h-5 w-5 text-rose-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <div>
              <div className="text-xs font-semibold text-white">Thermal Jacket Scale Fouling / Runaway</div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Drives bearing temp to 86°C, creating high thermal delta (&gt;60°C) and lowering heat dissipation factor.
              </p>
            </div>
          </button>

          <button
            onClick={() => handleInjectAndClose('cavitation')}
            className="w-full p-3 text-left rounded-lg bg-slate-950/60 border border-sky-900/40 hover:border-sky-600/60 hover:bg-sky-950/20 transition-all flex items-start gap-3 cursor-pointer group"
          >
            <Droplets className="h-5 w-5 text-sky-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <div>
              <div className="text-xs font-semibold text-white">Hydraulic Line Cavitation / Vapor Collapse</div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Drops operating pressure to 104 bar and triggers severe pressure ripple variance (6.8 bar²).
              </p>
            </div>
          </button>

          <button
            onClick={() => handleInjectAndClose('overstrain')}
            className="w-full p-3 text-left rounded-lg bg-slate-950/60 border border-purple-900/40 hover:border-purple-600/60 hover:bg-purple-950/20 transition-all flex items-start gap-3 cursor-pointer group"
          >
            <Zap className="h-5 w-5 text-purple-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <div>
              <div className="text-xs font-semibold text-white">Mechanical Coupling Binding &amp; Torque Strain</div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Spikes torque load to 88 Nm and electrical power consumption to 22 kW.
              </p>
            </div>
          </button>
        </div>

        {/* Reset Action */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={handleResetAndClose}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-950/40 border border-emerald-800/40 rounded-lg hover:bg-emerald-900/40 transition-colors cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset {currentMachine.id} to Nominal Baseline</span>
          </button>

          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
