import React, { useState } from 'react';
import { MachineAsset, SensorReading } from '../types/telemetry';
import { Activity, Play, Pause, Zap, RefreshCw, BarChart2, SlidersHorizontal } from 'lucide-react';

interface LiveTelemetryStreamProps {
  machines: MachineAsset[];
  selectedMachineId: string;
  onSelectMachine: (id: string) => void;
  isStreaming: boolean;
  setIsStreaming: (streaming: boolean) => void;
  onInjectFault: (machineId: string, faultType: string) => void;
  onResetFault: (machineId: string) => void;
  onNavigateToDataEntry?: (machineId: string) => void;
}

export const LiveTelemetryStream: React.FC<LiveTelemetryStreamProps> = ({
  machines,
  selectedMachineId,
  onSelectMachine,
  isStreaming,
  setIsStreaming,
  onInjectFault,
  onResetFault,
  onNavigateToDataEntry,
}) => {
  const [selectedChannel, setSelectedChannel] = useState<'vibration' | 'temperature' | 'pressure' | 'kurtosis'>('vibration');

  const machine = machines.find(m => m.id === selectedMachineId) || machines[0];
  const history = machine.telemetry_history || [];
  const current = machine.current_readings;

  // Chart coordinate calculation for SVG waveform
  const chartHeight = 160;
  const chartWidth = 720;
  const dataPoints = history.slice(-25);

  const getPoints = (key: keyof SensorReading, minVal: number, maxVal: number) => {
    if (dataPoints.length === 0) return '';
    return dataPoints
      .map((pt, idx) => {
        const x = (idx / (dataPoints.length - 1 || 1)) * chartWidth;
        const val = Number(pt[key]);
        const normalized = Math.max(0, Math.min(1, (val - minVal) / (maxVal - minVal || 1)));
        const y = chartHeight - normalized * (chartHeight - 20) - 10;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const vibPoints = getPoints('vibration_rms', 0, 8.0);
  const tempPoints = getPoints('temperature_bearing', 30, 95);
  const pressPoints = getPoints('pressure_hydraulic', 90, 190);
  const kurtPoints = getPoints('vibration_kurtosis', 2.0, 10.0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Live High-Frequency Telemetry Ingest
          </h1>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <span>Edge Gateway Sampling: 20 Hz</span>
            <span aria-hidden="true">·</span>
            <span>Rolling 25-Point Oscillogram</span>
            <span aria-hidden="true">·</span>
            <span className={isStreaming ? 'text-emerald-400 font-medium' : 'text-slate-500'}>
              {isStreaming ? '● Ingestion Pipeline Streaming' : '○ Stream Paused'}
            </span>
          </div>
        </div>

        {/* Streaming Controls */}
        <div className="flex items-center gap-2">
          {onNavigateToDataEntry && (
            <button
              onClick={() => onNavigateToDataEntry(selectedMachineId)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-cyan-950/40 border border-cyan-800/40 text-cyan-300 hover:bg-cyan-900/40 transition-colors cursor-pointer"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Enter Sensor Data</span>
            </button>
          )}

          <button
            onClick={() => setIsStreaming(!isStreaming)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
              isStreaming
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-emerald-950/40 border-emerald-800/40 text-emerald-300 hover:bg-emerald-900/40'
            }`}
          >
            {isStreaming ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            <span>{isStreaming ? 'Pause Ingest' : 'Resume Stream'}</span>
          </button>

          {/* Machine Selector */}
          <select
            value={selectedMachineId}
            onChange={(e) => onSelectMachine(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          >
            {machines.map(m => (
              <option key={m.id} value={m.id}>
                {m.id}: {m.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Sensor Channel Selector Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
          <button
            onClick={() => setSelectedChannel('vibration')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedChannel === 'vibration' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Vibration RMS (ISO 10816)
          </button>
          <button
            onClick={() => setSelectedChannel('kurtosis')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedChannel === 'kurtosis' ? 'bg-slate-800 text-amber-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Vibration Kurtosis
          </button>
          <button
            onClick={() => setSelectedChannel('temperature')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedChannel === 'temperature' ? 'bg-slate-800 text-rose-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Bearing Temperature (°C)
          </button>
          <button
            onClick={() => setSelectedChannel('pressure')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedChannel === 'pressure' ? 'bg-slate-800 text-blue-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Hydraulic Pressure (bar)
          </button>
        </div>

        <div className="flex items-center gap-2">
          {machine.active_fault ? (
            <button
              onClick={() => onResetFault(machine.id)}
              className="px-3 py-1 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 rounded-md hover:bg-emerald-900/40 transition-colors cursor-pointer"
            >
              Clear Active Fault ({machine.active_fault})
            </button>
          ) : (
            <div className="flex gap-1.5">
              <button
                onClick={() => onInjectFault(machine.id, 'bearing')}
                className="px-2.5 py-1 text-xs text-amber-300 bg-amber-950/30 border border-amber-800/30 rounded-md hover:bg-amber-900/40 transition-colors cursor-pointer"
              >
                +Bearing Spall
              </button>
              <button
                onClick={() => onInjectFault(machine.id, 'thermal')}
                className="px-2.5 py-1 text-xs text-rose-300 bg-rose-950/30 border border-rose-800/30 rounded-md hover:bg-rose-900/40 transition-colors cursor-pointer"
              >
                +Heat Overload
              </button>
              <button
                onClick={() => onInjectFault(machine.id, 'cavitation')}
                className="px-2.5 py-1 text-xs text-sky-300 bg-sky-950/30 border border-sky-800/30 rounded-md hover:bg-sky-900/40 transition-colors cursor-pointer"
              >
                +Cavitation Drop
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Large Dynamic Waveform Canvas / SVG */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">
              {selectedChannel === 'vibration' && 'ISO 10816-3 Velocity RMS Trend (0.0 – 8.0 mm/s)'}
              {selectedChannel === 'kurtosis' && 'Non-Gaussian Impulsive Kurtosis Trend (2.0 – 10.0 ratio)'}
              {selectedChannel === 'temperature' && 'Bearing Surface Temperature Trend (30 – 95 °C)'}
              {selectedChannel === 'pressure' && 'Hydraulic Operating Pressure (90 – 190 bar)'}
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              Asset: {machine.name} ({machine.id}) · Live Ingestion Interval: 1.5s
            </span>
          </div>

          {/* Current Live Metric Badge */}
          <div className="text-right font-mono">
            <span className="text-2xl font-bold tabular-nums text-white">
              {selectedChannel === 'vibration' && `${current.vibration_rms.toFixed(2)} mm/s`}
              {selectedChannel === 'kurtosis' && `${current.vibration_kurtosis.toFixed(2)}`}
              {selectedChannel === 'temperature' && `${current.temperature_bearing.toFixed(1)} °C`}
              {selectedChannel === 'pressure' && `${current.pressure_hydraulic.toFixed(1)} bar`}
            </span>
            <div className="text-[11px] text-slate-400">
              {selectedChannel === 'vibration' && (current.vibration_rms > 4.5 ? 'Zone C: Unsatisfactory' : current.vibration_rms > 2.8 ? 'Zone B: Acceptable' : 'Zone A: Good')}
              {selectedChannel === 'kurtosis' && (current.vibration_kurtosis > 4.0 ? 'Impulsive Defect Active' : 'Normal Gaussian Noise')}
              {selectedChannel === 'temperature' && (current.temperature_bearing > 70 ? 'High Thermal Runaway Risk' : 'Normal Heat Dissipation')}
              {selectedChannel === 'pressure' && (current.pressure_hydraulic < 120 ? 'Cavitation Inception Risk' : 'Nominal Fluid Pressure')}
            </div>
          </div>
        </div>

        {/* SVG Oscillogram */}
        <div className="relative w-full overflow-hidden rounded-lg bg-slate-950 p-2 border border-slate-800/80">
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-52 overflow-visible">
            <defs>
              <linearGradient id="vibFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Horizontal Grid & Threshold lines */}
            <line x1="0" y1={chartHeight * 0.25} x2={chartWidth} y2={chartHeight * 0.25} stroke="#334155" strokeWidth="0.8" strokeDasharray="4 4" />
            <line x1="0" y1={chartHeight * 0.5} x2={chartWidth} y2={chartHeight * 0.5} stroke="#334155" strokeWidth="0.8" strokeDasharray="4 4" />
            <line x1="0" y1={chartHeight * 0.75} x2={chartWidth} y2={chartHeight * 0.75} stroke="#334155" strokeWidth="0.8" strokeDasharray="4 4" />

            {/* ISO 10816 Zone Band Fill for Vibration */}
            {selectedChannel === 'vibration' && (
              <>
                {/* Critical Zone D Top fill */}
                <rect x="0" y="0" width={chartWidth} height={chartHeight * 0.25} fill="#f43f5e" fillOpacity="0.08" />
                <text x="10" y="16" fill="#f43f5e" fontSize="9" fontFamily="monospace">ZONE D: UNACCEPTABLE &gt;7.1 mm/s</text>
                <text x="10" y={chartHeight * 0.5 - 6} fill="#f59e0b" fontSize="9" fontFamily="monospace">ZONE C: RESTRICTED 4.5 - 7.1 mm/s</text>
                <text x="10" y={chartHeight - 12} fill="#10b981" fontSize="9" fontFamily="monospace">ZONE A/B: NORMAL OPERATING REGION</text>
              </>
            )}

            {/* Render Waveform Polyline based on active channel */}
            {selectedChannel === 'vibration' && (
              <polyline
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={vibPoints}
              />
            )}

            {selectedChannel === 'kurtosis' && (
              <polyline
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={kurtPoints}
              />
            )}

            {selectedChannel === 'temperature' && (
              <polyline
                fill="none"
                stroke="#f43f5e"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={tempPoints}
              />
            )}

            {selectedChannel === 'pressure' && (
              <polyline
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={pressPoints}
              />
            )}
          </svg>
        </div>

        {/* Telemetry Channel Reading Cards Grid */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-2.5">
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Vib Peak (g)</span>
            <span className="text-sm font-semibold font-mono tabular-nums text-white">
              {current.vibration_peak.toFixed(2)} g
            </span>
            <span className="text-[10px] text-slate-500 block">Impact accel</span>
          </div>

          <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-2.5">
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Crest Factor</span>
            <span className="text-sm font-semibold font-mono tabular-nums text-cyan-300">
              {(current.vibration_peak / Math.max(current.vibration_rms, 0.2)).toFixed(2)}
            </span>
            <span className="text-[10px] text-slate-500 block">Peak / RMS ratio</span>
          </div>

          <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-2.5">
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Ambient Temp</span>
            <span className="text-sm font-semibold font-mono tabular-nums text-white">
              {current.temperature_ambient.toFixed(1)} °C
            </span>
            <span className="text-[10px] text-slate-500 block">Factory floor</span>
          </div>

          <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-2.5">
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Thermal Delta</span>
            <span className="text-sm font-semibold font-mono tabular-nums text-rose-300">
              +{(current.temperature_bearing - current.temperature_ambient).toFixed(1)} °C
            </span>
            <span className="text-[10px] text-slate-500 block">Jacket delta</span>
          </div>

          <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-2.5">
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Motor Speed</span>
            <span className="text-sm font-semibold font-mono tabular-nums text-white">
              {current.rotational_speed} RPM
            </span>
            <span className="text-[10px] text-slate-500 block">Drive spindle</span>
          </div>

          <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-2.5">
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Acoustic dB</span>
            <span className="text-sm font-semibold font-mono tabular-nums text-white">
              {current.acoustic_emission.toFixed(1)} dB
            </span>
            <span className="text-[10px] text-slate-500 block">Ultrasonic HF</span>
          </div>
        </div>
      </div>
    </div>
  );
};
