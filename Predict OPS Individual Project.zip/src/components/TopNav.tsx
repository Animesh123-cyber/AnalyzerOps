import React from 'react';
import { Activity, Cpu, Terminal, Wrench, ShieldAlert, SlidersHorizontal } from 'lucide-react';

export type ActiveTab = 'fleet' | 'entry' | 'telemetry' | 'studio' | 'api' | 'orders';

interface TopNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  criticalCount: number;
  openStressModal: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  setActiveTab,
  criticalCount,
  openStressModal,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Activity className="h-4 w-4" />
          </div>
          <button 
            onClick={() => setActiveTab('fleet')}
            className="text-base font-bold tracking-tight text-white hover:text-cyan-300 transition-colors cursor-pointer"
          >
            ApexPredict
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single-line text affordances) */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setActiveTab('fleet')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'fleet'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            <span>Fleet Digital Twins</span>
          </button>

          <button
            onClick={() => setActiveTab('entry')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'entry'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span>Manual Data Ingest</span>
          </button>

          <button
            onClick={() => setActiveTab('telemetry')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'telemetry'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Cpu className="h-3.5 w-3.5" />
            <span>Live Oscillogram</span>
          </button>

          <button
            onClick={() => setActiveTab('studio')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'studio'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <ShieldAlert className="h-3.5 w-3.5" />
            <span>ML Model Studio</span>
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'api'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Terminal className="h-3.5 w-3.5" />
            <span>FastAPI Playground</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer relative ${
              activeTab === 'orders'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Wrench className="h-3.5 w-3.5" />
            <span>Work Orders</span>
            {criticalCount > 0 && (
              <span className="ml-1 inline-flex h-4 w-4 items-center justify-center rounded-full bg-rose-500/20 text-[10px] font-bold text-rose-400 border border-rose-500/40">
                {criticalCount}
              </span>
            )}
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={openStressModal}
            className="px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-lg hover:bg-amber-500/20 transition-colors whitespace-nowrap cursor-pointer"
          >
            Inject Fault Stress
          </button>
          
          <button
            onClick={() => setActiveTab('api')}
            className="hidden sm:inline-flex px-3.5 py-1.5 text-xs font-medium text-slate-950 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors whitespace-nowrap cursor-pointer font-semibold shadow-sm shadow-cyan-950"
          >
            POST /api/v1/predict
          </button>
        </div>
      </div>

      {/* Mobile navigation tab strip */}
      <div className="flex md:hidden overflow-x-auto border-t border-slate-900 px-3 py-2 gap-1.5">
        <button
          onClick={() => setActiveTab('fleet')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${
            activeTab === 'fleet' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Fleet Twins
        </button>
        <button
          onClick={() => setActiveTab('entry')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${
            activeTab === 'entry' ? 'bg-slate-800 text-cyan-300' : 'text-slate-400'
          }`}
        >
          Enter Data
        </button>
        <button
          onClick={() => setActiveTab('telemetry')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${
            activeTab === 'telemetry' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Oscillogram
        </button>
        <button
          onClick={() => setActiveTab('studio')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${
            activeTab === 'studio' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          ML Studio
        </button>
        <button
          onClick={() => setActiveTab('api')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${
            activeTab === 'api' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          FastAPI Docs
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${
            activeTab === 'orders' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Work Orders {criticalCount > 0 ? `(${criticalCount})` : ''}
        </button>
      </div>
    </header>
  );
};
