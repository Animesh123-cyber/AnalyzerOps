import React, { useState } from 'react';
import { SensorReading, PredictionResponse } from '../types/telemetry';
import { fetchPrediction } from '../services/apiService';
import { PYTHON_PROJECT_FILES } from '../data/pythonExportFiles';
import { Terminal, Send, Copy, Check, Download, FileCode, Play, Sparkles } from 'lucide-react';

interface ApiWorkbenchProps {
  initialReading?: SensorReading;
  initialMachineId?: string;
}

export const ApiWorkbench: React.FC<ApiWorkbenchProps> = ({
  initialReading,
  initialMachineId = 'EQ-204',
}) => {
  const [activeTab, setActiveTab] = useState<'tester' | 'python_code'>('tester');
  const [selectedPythonFile, setSelectedPythonFile] = useState<string>('app.py');
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  // Request body state
  const defaultBody = {
    machine_id: initialMachineId,
    temperature_bearing: initialReading?.temperature_bearing ?? 68.4,
    temperature_ambient: initialReading?.temperature_ambient ?? 24.2,
    vibration_rms: initialReading?.vibration_rms ?? 3.82,
    vibration_peak: initialReading?.vibration_peak ?? 6.10,
    vibration_kurtosis: initialReading?.vibration_kurtosis ?? 5.92,
    pressure_hydraulic: initialReading?.pressure_hydraulic ?? 147.5,
    pressure_variance: initialReading?.pressure_variance ?? 1.45,
    rotational_speed: initialReading?.rotational_speed ?? 3150,
    motor_torque: initialReading?.motor_torque ?? 48.2,
    acoustic_emission: initialReading?.acoustic_emission ?? 64.5,
  };

  const [requestJson, setRequestJson] = useState<string>(
    JSON.stringify(defaultBody, null, 2)
  );

  const [response, setResponse] = useState<PredictionResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Preset scenarios
  const applyPreset = (presetName: string) => {
    let presetData: any = { ...defaultBody };

    if (presetName === 'nominal') {
      presetData = {
        machine_id: 'EQ-101',
        temperature_bearing: 51.5,
        temperature_ambient: 24.0,
        vibration_rms: 1.55,
        vibration_peak: 2.30,
        vibration_kurtosis: 3.02,
        pressure_hydraulic: 152.0,
        pressure_variance: 0.80,
        rotational_speed: 1780,
        motor_torque: 41.5,
        acoustic_emission: 43.0,
      };
    } else if (presetName === 'bearing_fault') {
      presetData = {
        machine_id: 'EQ-204',
        temperature_bearing: 67.2,
        temperature_ambient: 24.5,
        vibration_rms: 4.85,
        vibration_peak: 7.40,
        vibration_kurtosis: 6.80, // Impulsive impact spikes
        pressure_hydraulic: 148.0,
        pressure_variance: 1.20,
        rotational_speed: 3150,
        motor_torque: 47.0,
        acoustic_emission: 72.0, // High ultrasonic emission
      };
    } else if (presetName === 'thermal_clog') {
      presetData = {
        machine_id: 'EQ-415',
        temperature_bearing: 86.5, // Extreme thermal delta
        temperature_ambient: 25.0,
        vibration_rms: 2.10,
        vibration_peak: 3.20,
        vibration_kurtosis: 3.15,
        pressure_hydraulic: 153.0,
        pressure_variance: 0.95,
        rotational_speed: 2940,
        motor_torque: 46.0,
        acoustic_emission: 49.0,
      };
    } else if (presetName === 'cavitation') {
      presetData = {
        machine_id: 'EQ-308',
        temperature_bearing: 56.0,
        temperature_ambient: 24.0,
        vibration_rms: 2.90,
        vibration_peak: 4.10,
        vibration_kurtosis: 3.60,
        pressure_hydraulic: 104.0, // Significant pressure drop
        pressure_variance: 6.80,  // Severe ripple instability
        rotational_speed: 1240,
        motor_torque: 52.0,
        acoustic_emission: 58.0,
      };
    } else if (presetName === 'torque_overload') {
      presetData = {
        machine_id: 'EQ-308',
        temperature_bearing: 62.0,
        temperature_ambient: 24.0,
        vibration_rms: 3.10,
        vibration_peak: 4.50,
        vibration_kurtosis: 3.40,
        pressure_hydraulic: 158.0,
        pressure_variance: 1.10,
        rotational_speed: 1240,
        motor_torque: 88.5, // High mechanical binding torque
        acoustic_emission: 55.0,
      };
    }

    setRequestJson(JSON.stringify(presetData, null, 2));
    setJsonError(null);
  };

  const handleExecuteRequest = async () => {
    try {
      setJsonError(null);
      const parsed = JSON.parse(requestJson);
      setIsLoading(true);

      const reading: SensorReading = {
        timestamp: new Date().toISOString(),
        temperature_bearing: Number(parsed.temperature_bearing),
        temperature_ambient: Number(parsed.temperature_ambient || 24.0),
        vibration_rms: Number(parsed.vibration_rms),
        vibration_peak: Number(parsed.vibration_peak),
        vibration_kurtosis: Number(parsed.vibration_kurtosis),
        pressure_hydraulic: Number(parsed.pressure_hydraulic),
        pressure_variance: Number(parsed.pressure_variance),
        rotational_speed: Number(parsed.rotational_speed),
        motor_torque: Number(parsed.motor_torque),
        acoustic_emission: Number(parsed.acoustic_emission || 44.0),
      };

      const result = await fetchPrediction(reading, parsed.machine_id || 'EQ-TEST');
      setResponse(result);
    } catch (err: any) {
      setJsonError(err.message || 'Invalid JSON format');
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(label);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const downloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const curlCommand = `curl -X POST "http://localhost:8000/api/v1/predict" \\
  -H "Content-Type: application/json" \\
  -d '${requestJson.replace(/\n/g, '').replace(/\s+/g, ' ')}'`;

  const activePyFile = PYTHON_PROJECT_FILES.find(f => f.filename === selectedPythonFile) || PYTHON_PROJECT_FILES[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            FastAPI Inference Endpoint &amp; Source Suite
          </h1>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <span>FastAPI OpenAPI Specification 3.1</span>
            <span aria-hidden="true">·</span>
            <span>Sub-5ms Inference Latency</span>
            <span aria-hidden="true">·</span>
            <span>Production Scikit-XGBoost + Pandas Pipeline</span>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('tester')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'tester' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Play className="h-3.5 w-3.5" />
            <span>Interactive Endpoint Tester</span>
          </button>
          <button
            onClick={() => setActiveTab('python_code')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'python_code' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="h-3.5 w-3.5" />
            <span>Python Source Code Export</span>
          </button>
        </div>
      </div>

      {activeTab === 'tester' ? (
        <div className="space-y-6">
          {/* Endpoint Bar & Preset Chips */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4 space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2 font-mono text-xs">
                <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                  POST
                </span>
                <span className="text-white font-semibold">/api/v1/predict</span>
                <span className="text-slate-500">HTTP/1.1</span>
              </div>

              {/* Preset Scenario Selectors */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-xs text-slate-500 mr-1">Load Preset:</span>
                <button
                  onClick={() => applyPreset('nominal')}
                  className="px-2 py-1 text-[11px] rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
                >
                  Nominal Baseline
                </button>
                <button
                  onClick={() => applyPreset('bearing_fault')}
                  className="px-2 py-1 text-[11px] rounded bg-amber-950/40 border border-amber-800/40 text-amber-300 hover:bg-amber-900/40 transition-colors cursor-pointer"
                >
                  Bearing Spall
                </button>
                <button
                  onClick={() => applyPreset('thermal_clog')}
                  className="px-2 py-1 text-[11px] rounded bg-rose-950/40 border border-rose-800/40 text-rose-300 hover:bg-rose-900/40 transition-colors cursor-pointer"
                >
                  Thermal Runaway
                </button>
                <button
                  onClick={() => applyPreset('cavitation')}
                  className="px-2 py-1 text-[11px] rounded bg-sky-950/40 border border-sky-800/40 text-sky-300 hover:bg-sky-900/40 transition-colors cursor-pointer"
                >
                  Cavitation Drop
                </button>
                <button
                  onClick={() => applyPreset('torque_overload')}
                  className="px-2 py-1 text-[11px] rounded bg-purple-950/40 border border-purple-800/40 text-purple-300 hover:bg-purple-900/40 transition-colors cursor-pointer"
                >
                  Torque Binding
                </button>
              </div>
            </div>
          </div>

          {/* Request & Response Split Panes */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Pane: Request Payload Editor */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-4 flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                    Request Body (JSON)
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">application/json</span>
                </div>
                <button
                  onClick={() => copyToClipboard(requestJson, 'request')}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  {copiedSnippet === 'request' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedSnippet === 'request' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {jsonError && (
                <div className="mb-3 p-2 bg-rose-950/40 border border-rose-800/40 rounded text-xs text-rose-300 font-mono">
                  Syntax Error: {jsonError}
                </div>
              )}

              <div className="relative flex-1 min-h-[360px]">
                <textarea
                  value={requestJson}
                  onChange={(e) => {
                    setRequestJson(e.target.value);
                    setJsonError(null);
                  }}
                  className="w-full h-full min-h-[360px] p-3 bg-slate-950 font-mono text-xs text-cyan-200 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-cyan-500 resize-none tabular-nums"
                  spellCheck={false}
                />
              </div>

              <div className="pt-3 flex items-center justify-between gap-3 mt-auto">
                <span className="text-[11px] text-slate-500 font-mono">
                  Schema: Pydantic v2 SensorTelemetryInput
                </span>
                <button
                  onClick={handleExecuteRequest}
                  disabled={isLoading}
                  className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-cyan-400 text-slate-950 hover:bg-cyan-300 transition-colors shadow-sm shadow-cyan-950 cursor-pointer"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>{isLoading ? 'Running Inference...' : 'Send Request'}</span>
                </button>
              </div>
            </div>

            {/* Right Pane: Response Viewer */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-4 flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                    Response Payload
                  </span>
                  {response && (
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">
                      200 OK · {response.latency_ms} ms
                    </span>
                  )}
                </div>
                {response && (
                  <button
                    onClick={() => copyToClipboard(JSON.stringify(response, null, 2), 'response')}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    {copiedSnippet === 'response' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    <span>{copiedSnippet === 'response' ? 'Copied' : 'Copy'}</span>
                  </button>
                )}
              </div>

              {response ? (
                <div className="space-y-3 flex-1 flex flex-col">
                  {/* High level visual summary card */}
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">Predicted Failure Mode:</span>
                      <span className="font-semibold text-white">{response.failure_mode_label}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono pt-1 border-t border-slate-900">
                      <div>
                        <span className="text-[10px] text-slate-500 block">FAILURE PROB</span>
                        <span className="font-bold text-amber-400 tabular-nums">
                          {(response.failure_probability * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">HEALTH INDEX</span>
                        <span className="font-bold text-white tabular-nums">{response.health_index}%</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">RUL ESTIMATE</span>
                        <span className="font-bold text-cyan-300 tabular-nums">
                          {response.remaining_useful_life_hours} hrs
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Raw JSON Code block */}
                  <div className="relative flex-1 min-h-[260px] bg-slate-950 rounded-lg p-3 border border-slate-800 overflow-auto">
                    <pre className="font-mono text-[11px] text-emerald-300/90 whitespace-pre leading-relaxed tabular-nums">
                      {JSON.stringify(response, null, 2)}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500 min-h-[360px] bg-slate-950/60 rounded-lg border border-slate-800/60">
                  <Terminal className="h-8 w-8 mb-2 text-slate-600" />
                  <p className="text-xs text-slate-400 font-medium">Ready for Inference</p>
                  <p className="text-[11px] text-slate-500 mt-1 max-w-xs">
                    Click &quot;Send Request&quot; above to execute the predictive maintenance pipeline against the live endpoint.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* cURL & Code Generator snippet */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                Direct cURL Terminal Command
              </span>
              <button
                onClick={() => copyToClipboard(curlCommand, 'curl')}
                className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {copiedSnippet === 'curl' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                <span>{copiedSnippet === 'curl' ? 'Copied' : 'Copy cURL'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-lg font-mono text-xs text-slate-300 overflow-x-auto border border-slate-800">
              {curlCommand}
            </pre>
          </div>
        </div>
      ) : (
        /* Tab 2: Full Python Source Code Suite */
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2 overflow-x-auto">
              {PYTHON_PROJECT_FILES.map(file => (
                <button
                  key={file.filename}
                  onClick={() => setSelectedPythonFile(file.filename)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg font-mono transition-colors whitespace-nowrap cursor-pointer ${
                    selectedPythonFile === file.filename
                      ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {file.filename}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => copyToClipboard(activePyFile.code, activePyFile.filename)}
                className="flex items-center gap-1 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                {copiedSnippet === activePyFile.filename ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedSnippet === activePyFile.filename ? 'Copied' : 'Copy File'}</span>
              </button>

              <button
                onClick={() => downloadFile(activePyFile.filename, activePyFile.code)}
                className="flex items-center gap-1 px-3 py-1.5 text-xs text-cyan-300 bg-cyan-950/40 border border-cyan-800/40 rounded-lg hover:bg-cyan-900/40 transition-colors cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download {activePyFile.filename}</span>
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-4">
            <div className="mb-3 text-xs text-slate-400 font-mono">
              <span className="font-semibold text-white">{activePyFile.filename}</span> — {activePyFile.description}
            </div>
            <div className="relative rounded-lg bg-slate-950 p-4 border border-slate-800/80 overflow-x-auto max-h-[580px]">
              <pre className="font-mono text-xs text-slate-200 leading-relaxed">
                {activePyFile.code}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
