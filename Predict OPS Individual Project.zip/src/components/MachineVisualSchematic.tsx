import React from 'react';
import { MachineAsset } from '../types/telemetry';

interface SchematicProps {
  machine: MachineAsset;
  className?: string;
}

export const MachineVisualSchematic: React.FC<SchematicProps> = ({ machine, className = '' }) => {
  const { type, current_readings, status } = machine;
  const temp = current_readings.temperature_bearing;
  const vib = current_readings.vibration_rms;
  const pressure = current_readings.pressure_hydraulic;

  // Thermal color gradient based on temperature
  let thermalFill = '#06b6d4'; // cyan nominal
  if (temp > 75) thermalFill = '#f43f5e'; // red critical
  else if (temp > 62) thermalFill = '#f59e0b'; // amber warning

  // Vibration stroke dash / ripple
  const isVibrating = vib > 3.0;

  return (
    <div className={`relative overflow-hidden rounded-lg bg-slate-900/80 border border-slate-800 p-3 ${className}`}>
      <div className="flex items-center justify-between text-xs text-slate-400 mb-2 border-b border-slate-800/60 pb-1.5">
        <span className="font-medium text-slate-200">{machine.name}</span>
        <div className="flex items-center gap-2 font-mono text-[11px] tabular-nums">
          <span className="text-slate-400">{current_readings.rotational_speed} RPM</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span style={{ color: thermalFill }}>{temp.toFixed(1)}°C</span>
        </div>
      </div>

      <div className="relative aspect-[16/9] w-full flex items-center justify-center bg-slate-950/60 rounded border border-slate-800/40 p-2">
        {type === 'Centrifugal Pump' && (
          <svg viewBox="0 0 400 220" className="w-full h-full max-h-44 text-slate-400 select-none">
            <defs>
              <linearGradient id="casingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#1e293b" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>
              <radialGradient id="heatGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor={thermalFill} stopOpacity="0.8" />
                <stop offset="100%" stopColor={thermalFill} stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Impeller Volute Casing */}
            <path
              d="M 120 110 C 120 60, 200 40, 260 70 C 310 95, 310 160, 250 180 C 190 200, 120 170, 120 110 Z"
              fill="url(#casingGrad)"
              stroke="#334155"
              strokeWidth="2.5"
            />
            {/* Discharge Nozzle */}
            <rect x="230" y="20" width="36" height="55" fill="#1e293b" stroke="#334155" strokeWidth="2" />
            <path d="M 220 20 L 276 20" stroke="#475569" strokeWidth="4" />
            
            {/* Suction Inlet Flange */}
            <ellipse cx="80" cy="110" rx="14" ry="32" fill="#0f172a" stroke="#334155" strokeWidth="2" />
            <rect x="80" y="86" width="44" height="48" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />

            {/* Rotating Impeller Vanes */}
            <g transform="translate(210, 120)">
              <circle cx="0" cy="0" r="42" fill="none" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
              <g className="origin-center animate-spin" style={{ animationDuration: `${Math.max(0.6, 3600 / current_readings.rotational_speed)}s` }}>
                <line x1="-34" y1="0" x2="34" y2="0" stroke="#06b6d4" strokeWidth="2.5" strokeLinecap="round" />
                <line x1="0" y1="-34" x2="0" y2="34" stroke="#06b6d4" strokeWidth="2.5" strokeLinecap="round" />
                <circle cx="0" cy="0" r="10" fill="#0284c7" />
              </g>
            </g>

            {/* Bearing Bracket & Drive Shaft */}
            <rect x="270" y="105" width="90" height="30" rx="3" fill="#1e293b" stroke="#334155" strokeWidth="2" />
            
            {/* Bearing Hotspot Glow */}
            <circle cx="295" cy="120" r="22" fill="url(#heatGlow)" />
            <circle cx="295" cy="120" r="12" fill={thermalFill} opacity="0.9" />
            <circle cx="340" cy="120" r="9" fill="#0284c7" />

            {/* Vibration Sensor Indicator */}
            <g transform="translate(295, 90)">
              <rect x="-6" y="-12" width="12" height="12" fill="#0284c7" rx="1" />
              {isVibrating && (
                <path d="M -10 -16 Q -5 -22 0 -16 Q 5 -22 10 -16" stroke="#f43f5e" fill="none" strokeWidth="1.5" className="animate-pulse" />
              )}
            </g>

            {/* Technical Labels */}
            <text x="295" y="152" fill="#94a3b8" fontSize="9" textAnchor="middle" fontFamily="monospace">DE BEARING</text>
            <text x="210" y="180" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">VOLUTE CASING</text>
          </svg>
        )}

        {type === 'CNC Spindle' && (
          <svg viewBox="0 0 400 220" className="w-full h-full max-h-44 text-slate-400 select-none">
            <defs>
              <linearGradient id="spindleBody" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#334155" />
                <stop offset="50%" stopColor="#1e293b" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>
            </defs>

            {/* Outer Spindle Cartridge Sleeve */}
            <rect x="60" y="65" width="250" height="90" rx="4" fill="url(#spindleBody)" stroke="#475569" strokeWidth="2" />
            
            {/* Cooling Jacket Channels */}
            <line x1="80" y1="75" x2="280" y2="75" stroke="#0284c7" strokeWidth="2" strokeDasharray="6 4" />
            <line x1="80" y1="145" x2="280" y2="145" stroke="#0284c7" strokeWidth="2" strokeDasharray="6 4" />

            {/* Front Duplex Angular Contact Bearings */}
            <g transform="translate(100, 110)">
              <circle cx="0" cy="0" r="18" fill={thermalFill} opacity="0.85" />
              <circle cx="0" cy="0" r="9" fill="#0f172a" stroke="#fff" strokeWidth="1.5" />
              <text x="0" y="32" fill="#94a3b8" fontSize="8" textAnchor="middle" fontFamily="monospace">FRONT BEARING SET</text>
            </g>

            {/* Rear Bearing Set */}
            <g transform="translate(260, 110)">
              <circle cx="0" cy="0" r="14" fill="#0284c7" opacity="0.85" />
              <circle cx="0" cy="0" r="7" fill="#0f172a" stroke="#fff" strokeWidth="1.5" />
              <text x="0" y="32" fill="#94a3b8" fontSize="8" textAnchor="middle" fontFamily="monospace">REAR BEARING</text>
            </g>

            {/* Central High Frequency Rotor */}
            <rect x="80" y="100" width="210" height="20" fill="#475569" stroke="#64748b" strokeWidth="1" />
            
            {/* Tool Holder Taper (HSK-63A) & Endmill */}
            <polygon points="60,95 20,105 20,115 60,125" fill="#64748b" stroke="#94a3b8" strokeWidth="1.5" />
            <rect x="2" y="107" width="18" height="6" fill="#cbd5e1" />

            {/* Runout Sensor */}
            <g transform="translate(100, 48)">
              <circle cx="0" cy="0" r="4" fill="#f59e0b" />
              <line x1="0" y1="4" x2="0" y2="16" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="2 2" />
              <text x="0" y="-8" fill="#f59e0b" fontSize="8" textAnchor="middle" fontFamily="monospace">EDDY-CURRENT RUNOUT</text>
            </g>

            {/* Spindle Vibration Shock Wave */}
            {isVibrating && (
              <g transform="translate(60, 110)" className="animate-pulse">
                <circle cx="0" cy="0" r="26" fill="none" stroke="#f43f5e" strokeWidth="1.5" opacity="0.7" />
                <circle cx="0" cy="0" r="34" fill="none" stroke="#f43f5e" strokeWidth="1" opacity="0.4" />
              </g>
            )}
          </svg>
        )}

        {type === 'Hydraulic Press' && (
          <svg viewBox="0 0 400 220" className="w-full h-full max-h-44 text-slate-400 select-none">
            {/* Press Crown & Uprights */}
            <rect x="90" y="25" width="220" height="35" rx="3" fill="#1e293b" stroke="#475569" strokeWidth="2" />
            <rect x="100" y="60" width="25" height="110" fill="#0f172a" stroke="#334155" strokeWidth="2" />
            <rect x="275" y="60" width="25" height="110" fill="#0f172a" stroke="#334155" strokeWidth="2" />
            <rect x="80" y="170" width="240" height="30" rx="3" fill="#1e293b" stroke="#475569" strokeWidth="2" />

            {/* Main Hydraulic Cylinder & Ram */}
            <rect x="165" y="30" width="70" height="60" rx="2" fill="#334155" stroke="#64748b" strokeWidth="1.5" />
            <rect x="180" y="90" width="40" height="45" fill="#94a3b8" stroke="#cbd5e1" strokeWidth="1" />
            <rect x="140" y="135" width="120" height="18" rx="2" fill="#475569" stroke="#64748b" strokeWidth="1.5" />

            {/* High Pressure Hydraulic Fluid Indicator */}
            <g transform="translate(255, 45)">
              <rect x="0" y="0" width="10" height="40" fill={pressure > 165 ? '#f43f5e' : '#0284c7'} rx="2" />
              <text x="16" y="24" fill="#94a3b8" fontSize="8" fontFamily="monospace">{pressure.toFixed(0)} BAR</text>
            </g>
            <text x="200" y="20" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">MAIN CYLINDER 450T</text>
          </svg>
        )}

        {type === 'Gas Compressor' && (
          <svg viewBox="0 0 400 220" className="w-full h-full max-h-44 text-slate-400 select-none">
            {/* Turbine Housing Barrel */}
            <rect x="70" y="70" width="260" height="80" rx="6" fill="#1e293b" stroke="#475569" strokeWidth="2" />
            
            {/* Multistage Compressor Stages */}
            <polygon points="100,80 140,85 140,135 100,140" fill="#334155" stroke="#64748b" strokeWidth="1" />
            <polygon points="150,83 185,87 185,133 150,137" fill="#334155" stroke="#64748b" strokeWidth="1" />
            <polygon points="195,86 225,89 225,131 195,134" fill="#334155" stroke="#64748b" strokeWidth="1" />
            
            {/* Shaft & Bearings */}
            <line x1="50" y1="110" x2="350" y2="110" stroke="#94a3b8" strokeWidth="4" />
            <circle cx="85" cy="110" r="14" fill={thermalFill} opacity="0.8" />
            <circle cx="315" cy="110" r="14" fill="#0284c7" opacity="0.8" />
            
            {/* Gas Intake & Discharge Manifolds */}
            <rect x="95" y="30" width="30" height="40" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
            <rect x="270" y="30" width="30" height="40" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
            <text x="110" y="24" fill="#06b6d4" fontSize="8" textAnchor="middle" fontFamily="monospace">GAS INLET</text>
            <text x="285" y="24" fill="#f59e0b" fontSize="8" textAnchor="middle" fontFamily="monospace">DISCHARGE</text>
          </svg>
        )}
      </div>

      {/* Real-time Telemetry Bar */}
      <div className="mt-2.5 grid grid-cols-4 gap-1.5 text-center text-[10px] text-slate-400 font-mono">
        <div className="bg-slate-950/40 rounded p-1 border border-slate-800/40">
          <span className="text-slate-500 block text-[9px]">VIB RMS</span>
          <span className="font-semibold text-slate-200">{vib.toFixed(2)} mm/s</span>
        </div>
        <div className="bg-slate-950/40 rounded p-1 border border-slate-800/40">
          <span className="text-slate-500 block text-[9px]">KURTOSIS</span>
          <span className={`font-semibold ${current_readings.vibration_kurtosis > 4 ? 'text-amber-400' : 'text-slate-200'}`}>
            {current_readings.vibration_kurtosis.toFixed(2)}
          </span>
        </div>
        <div className="bg-slate-950/40 rounded p-1 border border-slate-800/40">
          <span className="text-slate-500 block text-[9px]">PRESSURE</span>
          <span className="font-semibold text-slate-200">{pressure.toFixed(1)} bar</span>
        </div>
        <div className="bg-slate-950/40 rounded p-1 border border-slate-800/40">
          <span className="text-slate-500 block text-[9px]">TORQUE</span>
          <span className="font-semibold text-slate-200">{current_readings.motor_torque.toFixed(1)} Nm</span>
        </div>
      </div>
    </div>
  );
};
