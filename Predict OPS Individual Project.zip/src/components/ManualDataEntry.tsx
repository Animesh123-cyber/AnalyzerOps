import React, { useState, useMemo } from 'react';
import { MachineAsset, SensorReading, PredictionResponse } from '../types/telemetry';
import { predictMachineState, NOMINAL_BASELINES } from '../services/mlEngine';
import { 
  SlidersHorizontal, 
  Upload, 
  PlusCircle, 
  Check, 
  AlertTriangle, 
  Clock, 
  RotateCcw, 
  FileSpreadsheet, 
  ArrowRight, 
  Download,
  Activity,
  Layers
} from 'lucide-react';

interface ManualDataEntryProps {
  machines: MachineAsset[];
  selectedMachineId: string;
  onSelectMachine: (id: string) => void;
  onUpdateMachineTelemetry: (machineId: string, reading: SensorReading) => void;
  onAddMachine: (newMachine: MachineAsset) => void;
  onBatchTelemetryImport: (machineId: string, readings: SensorReading[]) => void;
}

export const ManualDataEntry: React.FC<ManualDataEntryProps> = ({
  machines,
  selectedMachineId,
  onSelectMachine,
  onUpdateMachineTelemetry,
  onAddMachine,
  onBatchTelemetryImport,
}) => {
  const [entryMode, setEntryMode] = useState<'single' | 'batch' | 'register'>('single');

  // Selected target machine
  const currentMachine = machines.find(m => m.id === selectedMachineId) || machines[0];

  // Single form values
  const [tempBearing, setTempBearing] = useState<number>(currentMachine?.current_readings.temperature_bearing ?? 52.4);
  const [tempAmbient, setTempAmbient] = useState<number>(currentMachine?.current_readings.temperature_ambient ?? 24.0);
  const [vibRms, setVibRms] = useState<number>(currentMachine?.current_readings.vibration_rms ?? 1.65);
  const [vibPeak, setVibPeak] = useState<number>(currentMachine?.current_readings.vibration_peak ?? 2.45);
  const [vibKurtosis, setVibKurtosis] = useState<number>(currentMachine?.current_readings.vibration_kurtosis ?? 3.05);
  const [pressureHydraulic, setPressureHydraulic] = useState<number>(currentMachine?.current_readings.pressure_hydraulic ?? 152.0);
  const [pressureVariance, setPressureVariance] = useState<number>(currentMachine?.current_readings.pressure_variance ?? 0.85);
  const [rotationalSpeed, setRotationalSpeed] = useState<number>(currentMachine?.current_readings.rotational_speed ?? 2450);
  const [motorTorque, setMotorTorque] = useState<number>(currentMachine?.current_readings.motor_torque ?? 42.5);
  const [acousticEmission, setAcousticEmission] = useState<number>(currentMachine?.current_readings.acoustic_emission ?? 44.0);

  // Success indicator
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Batch import state
  const [csvText, setCsvText] = useState<string>('');
  const [batchResults, setBatchResults] = useState<{ reading: SensorReading; prediction: PredictionResponse }[] | null>(null);
  const [csvError, setCsvError] = useState<string | null>(null);

  // Register asset form state
  const [newTag, setNewTag] = useState<string>('MOTOR-CONVEYOR-03');
  const [newName, setNewName] = useState<string>('Heavy Induction Motor #03');
  const [newType, setNewType] = useState<'Centrifugal Pump' | 'CNC Spindle' | 'Hydraulic Press' | 'Gas Compressor'>('Centrifugal Pump');
  const [newLocation, setNewLocation] = useState<string>('Assembly Wing D, Primary Feed');
  const [newHours, setNewHours] = useState<number>(4200);

  // Sync inputs when user picks another machine
  const handleMachineSelect = (mId: string) => {
    onSelectMachine(mId);
    const m = machines.find(x => x.id === mId);
    if (m) {
      setTempBearing(m.current_readings.temperature_bearing);
      setTempAmbient(m.current_readings.temperature_ambient);
      setVibRms(m.current_readings.vibration_rms);
      setVibPeak(m.current_readings.vibration_peak);
      setVibKurtosis(m.current_readings.vibration_kurtosis);
      setPressureHydraulic(m.current_readings.pressure_hydraulic);
      setPressureVariance(m.current_readings.pressure_variance);
      setRotationalSpeed(m.current_readings.rotational_speed);
      setMotorTorque(m.current_readings.motor_torque);
      setAcousticEmission(m.current_readings.acoustic_emission);
    }
  };

  // Real-time instantaneous ML prediction calculated as user edits any value
  const liveReading: SensorReading = useMemo(() => ({
    timestamp: new Date().toISOString(),
    temperature_bearing: tempBearing,
    temperature_ambient: tempAmbient,
    vibration_rms: vibRms,
    vibration_peak: vibPeak,
    vibration_kurtosis: vibKurtosis,
    pressure_hydraulic: pressureHydraulic,
    pressure_variance: pressureVariance,
    rotational_speed: rotationalSpeed,
    motor_torque: motorTorque,
    acoustic_emission: acousticEmission,
  }), [
    tempBearing, tempAmbient, vibRms, vibPeak, vibKurtosis,
    pressureHydraulic, pressureVariance, rotationalSpeed, motorTorque, acousticEmission
  ]);

  const livePrediction = useMemo(() => {
    return predictMachineState(liveReading, currentMachine?.id || 'MANUAL-01');
  }, [liveReading, currentMachine?.id]);

  // Submit manual telemetry into fleet stream
  const handleApplyToFleet = () => {
    onUpdateMachineTelemetry(currentMachine.id, liveReading);
    setSuccessMessage(`Telemetry pushed to ${currentMachine.id}. Live health updated to ${livePrediction.health_index}%.`);
    setTimeout(() => setSuccessMessage(null), 3500);
  };

  // Preset quick adjustments
  const handleQuickPreset = (type: 'nominal' | 'bearing_damage' | 'overheat' | 'cavitation' | 'torque_binding') => {
    if (type === 'nominal') {
      setTempBearing(52.4);
      setTempAmbient(24.0);
      setVibRms(1.65);
      setVibPeak(2.45);
      setVibKurtosis(3.05);
      setPressureHydraulic(152.0);
      setPressureVariance(0.85);
      setRotationalSpeed(2450);
      setMotorTorque(42.5);
      setAcousticEmission(44.0);
    } else if (type === 'bearing_damage') {
      setVibRms(4.85);
      setVibPeak(7.80);
      setVibKurtosis(6.90);
      setAcousticEmission(74.5);
    } else if (type === 'overheat') {
      setTempBearing(86.5);
      setTempAmbient(25.0);
    } else if (type === 'cavitation') {
      setPressureHydraulic(102.0);
      setPressureVariance(6.85);
    } else if (type === 'torque_binding') {
      setMotorTorque(86.0);
      setRotationalSpeed(Math.max(rotationalSpeed - 300, 1000));
    }
  };

  // Parse CSV
  const handleParseAndRunBatch = () => {
    try {
      setCsvError(null);
      if (!csvText.trim()) {
        setCsvError('Please paste or upload CSV sensor rows.');
        return;
      }

      const lines = csvText.trim().split('\n');
      if (lines.length < 2) {
        setCsvError('CSV must include header row and at least 1 data row.');
        return;
      }

      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      const required = ['vibration_rms', 'temperature_bearing'];
      for (const r of required) {
        if (!headers.includes(r)) {
          setCsvError(`Missing required column "${r}" in CSV header.`);
          return;
        }
      }

      const parsedReadings: SensorReading[] = [];
      const results: { reading: SensorReading; prediction: PredictionResponse }[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const vals = line.split(',').map(v => v.trim());
        const row: any = {};
        headers.forEach((h, idx) => {
          row[h] = parseFloat(vals[idx]) || 0;
        });

        const reading: SensorReading = {
          timestamp: new Date().toISOString(),
          temperature_bearing: row.temperature_bearing ?? 52.0,
          temperature_ambient: row.temperature_ambient ?? 24.0,
          vibration_rms: row.vibration_rms ?? 1.6,
          vibration_peak: row.vibration_peak ?? (row.vibration_rms * 1.5 || 2.4),
          vibration_kurtosis: row.vibration_kurtosis ?? 3.0,
          pressure_hydraulic: row.pressure_hydraulic ?? 152.0,
          pressure_variance: row.pressure_variance ?? 0.85,
          rotational_speed: row.rotational_speed ?? 2450,
          motor_torque: row.motor_torque ?? 42.0,
          acoustic_emission: row.acoustic_emission ?? 44.0,
        };

        const pred = predictMachineState(reading, currentMachine.id);
        parsedReadings.push(reading);
        results.push({ reading, prediction: pred });
      }

      setBatchResults(results);
      onBatchTelemetryImport(currentMachine.id, parsedReadings);
      setSuccessMessage(`Successfully processed and ingested ${results.length} sensor rows into ${currentMachine.id}.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      setCsvError(err.message || 'Failed to parse CSV');
    }
  };

  const handleDownloadTemplate = () => {
    const template = `vibration_rms,vibration_peak,vibration_kurtosis,temperature_bearing,temperature_ambient,pressure_hydraulic,pressure_variance,rotational_speed,motor_torque,acoustic_emission
1.55,2.30,3.02,51.8,24.0,152.0,0.82,2450,42.0,43.5
2.10,3.15,3.30,55.2,24.2,151.5,0.95,2450,43.5,46.0
3.85,5.80,5.40,64.5,24.5,148.0,1.25,2440,46.0,62.0
4.92,7.60,6.85,68.2,24.5,147.2,1.40,2430,48.0,73.5
`;
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'telemetry_sample_template.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  // Register new asset
  const handleRegisterNewAsset = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = `EQ-${Math.floor(500 + Math.random() * 499)}`;
    const baseline: SensorReading = {
      timestamp: new Date().toISOString(),
      temperature_bearing: 51.5,
      temperature_ambient: 24.0,
      vibration_rms: 1.55,
      vibration_peak: 2.30,
      vibration_kurtosis: 3.02,
      pressure_hydraulic: 152.0,
      pressure_variance: 0.82,
      rotational_speed: 1800,
      motor_torque: 42.0,
      acoustic_emission: 43.5,
    };

    const initialPrediction = predictMachineState(baseline, newId);

    const newMachine: MachineAsset = {
      id: newId,
      tag: newTag,
      name: newName,
      type: newType,
      location: newLocation,
      installed_date: new Date().toISOString().split('T')[0],
      operating_hours: newHours,
      status: initialPrediction.risk_level,
      health_index: initialPrediction.health_index,
      current_readings: baseline,
      telemetry_history: [baseline],
      latest_prediction: initialPrediction,
      component_health: {
        bearings: 98,
        hydraulic_seals: 96,
        cooling_jacket: 98,
        drive_shaft: 97,
      },
    };

    onAddMachine(newMachine);
    onSelectMachine(newId);
    setSuccessMessage(`New industrial asset ${newId} (${newName}) successfully registered to fleet!`);
    setEntryMode('single');
    setTimeout(() => setSuccessMessage(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Manual Sensor Telemetry &amp; Data Ingestion
          </h1>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            <span>Operator Manual Overrides</span>
            <span aria-hidden="true">·</span>
            <span>Batch Sensor Log Ingestion</span>
            <span aria-hidden="true">·</span>
            <span>Asset Registration</span>
          </div>
        </div>

        {/* Mode Switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
          <button
            onClick={() => setEntryMode('single')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              entryMode === 'single' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span>Sensor Calibrator</span>
          </button>

          <button
            onClick={() => setEntryMode('batch')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              entryMode === 'batch' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="h-3.5 w-3.5" />
            <span>Batch CSV Ingest</span>
          </button>

          <button
            onClick={() => setEntryMode('register')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              entryMode === 'register' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PlusCircle className="h-3.5 w-3.5" />
            <span>Add New Asset</span>
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successMessage && (
        <div className="flex items-center gap-2.5 p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/40 text-emerald-300 text-xs font-mono animate-in fade-in duration-200">
          <Check className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Mode 1: Single Sensor Ingestion / Live Calibrator */}
      {entryMode === 'single' && (
        <div className="space-y-6">
          {/* Target Machine Selection & Presets Bar */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <label className="text-xs font-medium text-slate-400 font-mono">
                Target Asset:
              </label>
              <select
                value={selectedMachineId}
                onChange={(e) => handleMachineSelect(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
              >
                {machines.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.id}: {m.name} ({m.type})
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Presets */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs text-slate-500 mr-1">Quick Presets:</span>
              <button
                onClick={() => handleQuickPreset('nominal')}
                className="px-2.5 py-1 text-xs rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              >
                Nominal
              </button>
              <button
                onClick={() => handleQuickPreset('bearing_damage')}
                className="px-2.5 py-1 text-xs rounded bg-amber-950/40 border border-amber-800/40 text-amber-300 hover:bg-amber-900/40 transition-colors cursor-pointer"
              >
                High Vibration
              </button>
              <button
                onClick={() => handleQuickPreset('overheat')}
                className="px-2.5 py-1 text-xs rounded bg-rose-950/40 border border-rose-800/40 text-rose-300 hover:bg-rose-900/40 transition-colors cursor-pointer"
              >
                Overheating
              </button>
              <button
                onClick={() => handleQuickPreset('cavitation')}
                className="px-2.5 py-1 text-xs rounded bg-sky-950/40 border border-sky-800/40 text-sky-300 hover:bg-sky-900/40 transition-colors cursor-pointer"
              >
                Cavitation
              </button>
              <button
                onClick={() => handleQuickPreset('torque_binding')}
                className="px-2.5 py-1 text-xs rounded bg-purple-950/40 border border-purple-800/40 text-purple-300 hover:bg-purple-900/40 transition-colors cursor-pointer"
              >
                Torque Stall
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Sensor Sliders & Inputs */}
            <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-slate-900/80 p-5 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-semibold text-white">
                  6-Channel Industrial Sensor Ingestion Matrix
                </h3>
                <span className="text-xs font-mono text-slate-400">
                  Instant ML Recalculation
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
                {/* 1. Vibration RMS */}
                <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-200">ISO 10816 Vibration RMS</span>
                    <div className="flex items-center gap-1 font-mono">
                      <input
                        type="number"
                        step="0.05"
                        min="0.2"
                        max="15.0"
                        value={vibRms}
                        onChange={(e) => setVibRms(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right text-cyan-300 font-semibold tabular-nums focus:outline-none focus:ring-1 focus:ring-cyan-500"
                      />
                      <span className="text-slate-500 text-[11px]">mm/s</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="10.0"
                    step="0.05"
                    value={vibRms}
                    onChange={(e) => setVibRms(parseFloat(e.target.value))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Good: &lt;1.8</span>
                    <span>Restricted: 4.5</span>
                    <span className="text-rose-400">Danger: &gt;7.1</span>
                  </div>
                </div>

                {/* 2. Vibration Kurtosis */}
                <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-200">Vibration Kurtosis Excess</span>
                    <div className="flex items-center gap-1 font-mono">
                      <input
                        type="number"
                        step="0.1"
                        min="1.5"
                        max="16.0"
                        value={vibKurtosis}
                        onChange={(e) => setVibKurtosis(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right text-amber-300 font-semibold tabular-nums focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                      <span className="text-slate-500 text-[11px]">ratio</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="2.0"
                    max="12.0"
                    step="0.1"
                    value={vibKurtosis}
                    onChange={(e) => setVibKurtosis(parseFloat(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Gaussian: ~3.0</span>
                    <span>Micro-defect: &gt;4.5</span>
                    <span className="text-rose-400">Spalling: &gt;7.0</span>
                  </div>
                </div>

                {/* 3. Bearing Temp */}
                <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-200">Bearing Surface Temperature</span>
                    <div className="flex items-center gap-1 font-mono">
                      <input
                        type="number"
                        step="0.5"
                        min="25"
                        max="130"
                        value={tempBearing}
                        onChange={(e) => setTempBearing(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right text-rose-300 font-semibold tabular-nums focus:outline-none focus:ring-1 focus:ring-rose-500"
                      />
                      <span className="text-slate-500 text-[11px]">°C</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="35"
                    max="110"
                    step="0.5"
                    value={tempBearing}
                    onChange={(e) => setTempBearing(parseFloat(e.target.value))}
                    className="w-full accent-rose-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Normal: 45–65°C</span>
                    <span>Warning: 75°C</span>
                    <span className="text-rose-400">Critical: &gt;88°C</span>
                  </div>
                </div>

                {/* 4. Hydraulic Pressure */}
                <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-200">Hydraulic Line Pressure</span>
                    <div className="flex items-center gap-1 font-mono">
                      <input
                        type="number"
                        step="1.0"
                        min="40"
                        max="260"
                        value={pressureHydraulic}
                        onChange={(e) => setPressureHydraulic(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right text-blue-300 font-semibold tabular-nums focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                      <span className="text-slate-500 text-[11px]">bar</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="60"
                    max="220"
                    step="1.0"
                    value={pressureHydraulic}
                    onChange={(e) => setPressureHydraulic(parseFloat(e.target.value))}
                    className="w-full accent-blue-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span className="text-rose-400">Cavitation: &lt;110</span>
                    <span>Nominal: 152 bar</span>
                    <span>Overpressure: &gt;185</span>
                  </div>
                </div>

                {/* 5. Motor Torque */}
                <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-200">Motor Load Torque</span>
                    <div className="flex items-center gap-1 font-mono">
                      <input
                        type="number"
                        step="0.5"
                        min="10"
                        max="120"
                        value={motorTorque}
                        onChange={(e) => setMotorTorque(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right text-purple-300 font-semibold tabular-nums focus:outline-none focus:ring-1 focus:ring-purple-500"
                      />
                      <span className="text-slate-500 text-[11px]">Nm</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="15"
                    max="105"
                    step="0.5"
                    value={motorTorque}
                    onChange={(e) => setMotorTorque(parseFloat(e.target.value))}
                    className="w-full accent-purple-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Baseline: 42 Nm</span>
                    <span>Heavy load: 60 Nm</span>
                    <span className="text-rose-400">Binding: &gt;75 Nm</span>
                  </div>
                </div>

                {/* 6. Rotational Speed */}
                <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-200">Rotational Speed</span>
                    <div className="flex items-center gap-1 font-mono">
                      <input
                        type="number"
                        step="50"
                        min="500"
                        max="5000"
                        value={rotationalSpeed}
                        onChange={(e) => setRotationalSpeed(parseInt(e.target.value) || 0)}
                        className="w-18 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right text-white font-semibold tabular-nums focus:outline-none focus:ring-1 focus:ring-cyan-500"
                      />
                      <span className="text-slate-500 text-[11px]">RPM</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="800"
                    max="4000"
                    step="25"
                    value={rotationalSpeed}
                    onChange={(e) => setRotationalSpeed(parseInt(e.target.value))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Idle: 1,200</span>
                    <span>Rated: 2,450 RPM</span>
                    <span>High: 3,600</span>
                  </div>
                </div>
              </div>

              {/* Secondary Telemetry Channels: Acoustic, Peak, Ambient, Variance */}
              <div className="pt-3 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Acoustic HF (dB)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={acousticEmission}
                    onChange={(e) => setAcousticEmission(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 font-mono text-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Peak Accel (g)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={vibPeak}
                    onChange={(e) => setVibPeak(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 font-mono text-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Ambient Temp (°C)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={tempAmbient}
                    onChange={(e) => setTempAmbient(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 font-mono text-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Pressure Ripple (σ²)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={pressureVariance}
                    onChange={(e) => setPressureVariance(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 font-mono text-slate-200 text-xs"
                  />
                </div>
              </div>

              {/* Primary Action Button */}
              <div className="pt-3 flex items-center justify-between">
                <span className="text-xs text-slate-500 font-mono">
                  Target: {currentMachine.name} ({currentMachine.id})
                </span>
                <button
                  onClick={handleApplyToFleet}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-semibold text-xs hover:bg-cyan-300 transition-colors cursor-pointer shadow-sm shadow-cyan-950"
                >
                  <Activity className="h-4 w-4" />
                  <span>Push Values to Fleet Stream</span>
                </button>
              </div>
            </div>

            {/* Right Col: Instant Live ML Diagnosis Preview */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                    Real-Time Model Verdict
                  </h3>
                  <span className="text-xs font-mono text-emerald-400">Inference: 2.4 ms</span>
                </div>

                <div className="mt-4 space-y-3">
                  {/* Status Banner */}
                  <div className={`p-3 rounded-lg border text-xs font-mono ${
                    livePrediction.risk_level === 'CRITICAL'
                      ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                      : livePrediction.risk_level === 'WARNING'
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                      : livePrediction.risk_level === 'MONITOR'
                      ? 'bg-sky-500/10 border-sky-500/30 text-sky-300'
                      : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  }`}>
                    <div className="font-semibold text-sm">{livePrediction.failure_mode_label}</div>
                    <div className="text-[11px] opacity-80 mt-1">Risk Status: {livePrediction.risk_level}</div>
                  </div>

                  {/* Quantitative Stats */}
                  <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                    <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 block">HEALTH INDEX</span>
                      <span className="text-lg font-bold text-white tabular-nums">{livePrediction.health_index}%</span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 block">FAILURE PROB</span>
                      <span className="text-lg font-bold text-amber-400 tabular-nums">
                        {(livePrediction.failure_probability * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5 text-cyan-400" />
                      Predicted RUL:
                    </span>
                    <span className="font-bold text-cyan-300 tabular-nums">
                      {livePrediction.remaining_useful_life_hours} hrs
                    </span>
                  </div>

                  {/* Top Contributing Feature */}
                  <div className="p-2.5 bg-slate-950/80 rounded border border-slate-800 text-xs">
                    <span className="text-[10px] text-slate-500 block font-mono uppercase mb-1">
                      Primary Risk Driver:
                    </span>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-200 font-medium">
                        {livePrediction.feature_contributions[0]?.label}
                      </span>
                      <span className="font-mono text-rose-400 font-bold tabular-nums">
                        +{livePrediction.feature_contributions[0]?.contribution}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Prescriptive Recommendation preview */}
              <div className="pt-3 border-t border-slate-800">
                <span className="text-[10px] text-slate-500 font-mono uppercase block mb-1.5">
                  Automated Recommendation:
                </span>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-2.5 rounded border border-slate-800">
                  {livePrediction.prescriptive_actions[0]}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Batch CSV Sensor Log Ingestion */}
      {entryMode === 'batch' && (
        <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Batch Sensor Telemetry Ingestion (CSV / Time-Series)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Upload or paste continuous multi-row sensor logs for bulk ML inference and historical playback.
              </p>
            </div>

            <button
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download CSV Template</span>
            </button>
          </div>

          {csvError && (
            <div className="p-3 bg-rose-950/40 border border-rose-800/40 rounded-lg text-xs text-rose-300 font-mono">
              Error: {csvError}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Paste CSV Sensor Readings (with header columns):
            </label>
            <textarea
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="vibration_rms,vibration_peak,vibration_kurtosis,temperature_bearing,temperature_ambient,pressure_hydraulic,pressure_variance,rotational_speed,motor_torque,acoustic_emission&#10;1.65,2.45,3.05,52.4,24.0,152.0,0.85,2450,42.5,44.0&#10;4.80,7.20,6.50,68.0,24.2,148.0,1.40,2420,48.0,72.0"
              className="w-full h-44 p-3 bg-slate-950 font-mono text-xs text-cyan-200 rounded-lg border border-slate-800 focus:outline-none focus:ring-1 focus:ring-cyan-500 resize-none tabular-nums"
              spellCheck={false}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <label className="text-xs text-slate-400 font-mono">Ingest into:</label>
              <select
                value={selectedMachineId}
                onChange={(e) => onSelectMachine(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1 font-mono"
              >
                {machines.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.id}: {m.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleParseAndRunBatch}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-semibold text-xs hover:bg-cyan-300 transition-colors cursor-pointer shadow-sm shadow-cyan-950"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Run Batch Inference &amp; Ingest</span>
            </button>
          </div>

          {/* Batch Ingestion Results Table */}
          {batchResults && batchResults.length > 0 && (
            <div className="pt-4 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                  Batch Inference Output ({batchResults.length} records processed)
                </h4>
              </div>

              <div className="overflow-x-auto rounded-lg border border-slate-800">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-950 text-slate-400 text-[11px] border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">Row</th>
                      <th className="p-2.5">Vib RMS</th>
                      <th className="p-2.5">Kurtosis</th>
                      <th className="p-2.5">Bearing Temp</th>
                      <th className="p-2.5">Pressure</th>
                      <th className="p-2.5">Predicted Mode</th>
                      <th className="p-2.5">Fail Prob</th>
                      <th className="p-2.5">Health</th>
                      <th className="p-2.5">RUL</th>
                      <th className="p-2.5">Risk</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-slate-950/40">
                    {batchResults.map((res, i) => (
                      <tr key={i} className="hover:bg-slate-900/60">
                        <td className="p-2.5 text-slate-500">#{i + 1}</td>
                        <td className="p-2.5 text-slate-200 tabular-nums">{res.reading.vibration_rms.toFixed(2)} mm/s</td>
                        <td className="p-2.5 text-slate-200 tabular-nums">{res.reading.vibration_kurtosis.toFixed(2)}</td>
                        <td className="p-2.5 text-slate-200 tabular-nums">{res.reading.temperature_bearing.toFixed(1)}°C</td>
                        <td className="p-2.5 text-slate-200 tabular-nums">{res.reading.pressure_hydraulic.toFixed(1)} bar</td>
                        <td className="p-2.5 font-sans font-medium text-white">{res.prediction.failure_mode_label}</td>
                        <td className="p-2.5 font-bold text-amber-400 tabular-nums">
                          {(res.prediction.failure_probability * 100).toFixed(0)}%
                        </td>
                        <td className="p-2.5 text-white tabular-nums">{res.prediction.health_index}%</td>
                        <td className="p-2.5 text-cyan-300 tabular-nums">{res.prediction.remaining_useful_life_hours}h</td>
                        <td className="p-2.5">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            res.prediction.risk_level === 'CRITICAL'
                              ? 'bg-rose-500/20 text-rose-400'
                              : res.prediction.risk_level === 'WARNING'
                              ? 'bg-amber-500/20 text-amber-400'
                              : res.prediction.risk_level === 'MONITOR'
                              ? 'bg-sky-500/20 text-sky-400'
                              : 'bg-emerald-500/20 text-emerald-400'
                          }`}>
                            {res.prediction.risk_level}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Mode 3: Add New Machine Asset */}
      {entryMode === 'register' && (
        <form onSubmit={handleRegisterNewAsset} className="rounded-xl border border-slate-800 bg-slate-900/80 p-5 space-y-5">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-semibold text-white">
              Register New Machinery Asset into Fleet
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Enables real-time predictive maintenance digital twin monitoring for new plant equipment.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Machine Asset Name:</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. High-Pressure Boiler Feed Pump #03"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Asset Identification Tag:</label>
              <input
                type="text"
                required
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="e.g. PUMP-BOILER-03"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-cyan-300 font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Machinery Class / Type:</label>
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value="Centrifugal Pump">Centrifugal Pump</option>
                <option value="CNC Spindle">CNC Milling Spindle</option>
                <option value="Hydraulic Press">Hydraulic Press</option>
                <option value="Gas Compressor">Industrial Gas Compressor</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Physical Plant Location:</label>
              <input
                type="text"
                required
                value={newLocation}
                onChange={(e) => setNewLocation(e.target.value)}
                placeholder="e.g. Utility Building B, Bay 2"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Initial Operating Hours:</label>
              <input
                type="number"
                min="0"
                value={newHours}
                onChange={(e) => setNewHours(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500 tabular-nums"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setEntryMode('single')}
              className="px-3 py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-semibold text-xs hover:bg-cyan-300 transition-colors cursor-pointer shadow-sm shadow-cyan-950"
            >
              <PlusCircle className="h-4 w-4" />
              <span>Register &amp; Initialize Digital Twin</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
