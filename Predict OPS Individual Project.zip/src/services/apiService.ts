import { 
  SensorReading, 
  PredictionResponse, 
  ModelMetrics, 
  MachineAsset 
} from '../types/telemetry';
import { predictMachineState, DEFAULT_MODEL_METRICS, simulateModelTraining } from './mlEngine';

export async function fetchPrediction(
  reading: SensorReading, 
  machine_id: string = 'ASSET-01'
): Promise<PredictionResponse> {
  try {
    const res = await fetch('/api/v1/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...reading, machine_id }),
    });

    if (res.ok) {
      return await res.json();
    }
  } catch {
    // Graceful fallback to client ML engine
  }

  // Fallback to client-side ML engine
  return predictMachineState(reading, machine_id);
}

export async function fetchModelMetrics(): Promise<ModelMetrics> {
  try {
    const res = await fetch('/api/v1/model/metrics');
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // Graceful fallback
  }

  return DEFAULT_MODEL_METRICS;
}

export async function trainModel(params: {
  estimators: number;
  learning_rate: number;
  max_depth: number;
  test_split: number;
  onProgress?: (progress: number, log: string) => void;
}): Promise<ModelMetrics> {
  try {
    // If backend training endpoint is active, we can call it or use our robust runner
    return await simulateModelTraining(params);
  } catch {
    return DEFAULT_MODEL_METRICS;
  }
}
