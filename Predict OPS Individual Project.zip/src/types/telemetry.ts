export type FailureMode = 
  | 'NORMAL'
  | 'BEARING_DEGRADATION'
  | 'HEAT_DISSIPATION_FAILURE'
  | 'CAVITATION_PRESSURE_LOSS'
  | 'OVERSTRAIN_POWER_FAILURE'
  | 'TOOL_WEAR_FAILURE';

export type MachineStatus = 'NOMINAL' | 'MONITOR' | 'WARNING' | 'CRITICAL';

export interface SensorReading {
  timestamp: string;
  temperature_bearing: number;    // °C (40 - 100)
  temperature_ambient: number;    // °C (20 - 35)
  vibration_rms: number;          // mm/s (0.5 - 12.0) ISO 10816
  vibration_peak: number;         // g (0.8 - 8.0)
  vibration_kurtosis: number;     // ratio (2.5 - 12.0)
  pressure_hydraulic: number;     // bar (80 - 200)
  pressure_variance: number;      // bar² (0.1 - 15.0)
  rotational_speed: number;       // RPM (1000 - 4000)
  motor_torque: number;           // Nm (20 - 100)
  acoustic_emission: number;      // dB (35 - 85)
}

export interface ExtractedFeatures {
  thermal_delta: number;           // bearing - ambient (°C)
  thermal_dissipation_factor: number;
  crest_factor: number;            // peak / rms
  kurtosis_excess: number;         // kurtosis - 3.0
  power_kw: number;                // (2 * pi * rpm * torque) / 60000
  pressure_flow_ratio: number;
  bearing_wear_index: number;      // composite metric
  hydraulic_instability: number;
  normalized_z_scores: Record<string, number>;
}

export interface FeatureContribution {
  feature: string;
  label: string;
  contribution: number; // percentage (0 - 100)
  direction: 'increases_risk' | 'decreases_risk' | 'neutral';
  measured_value: string;
  reference_nominal: string;
}

export interface PredictionResponse {
  prediction_id: string;
  machine_id: string;
  timestamp: string;
  failure_mode: FailureMode;
  failure_mode_label: string;
  failure_probability: number;      // 0.0 - 1.0
  confidence_score: number;         // 0.0 - 1.0
  health_index: number;             // 0 - 100%
  remaining_useful_life_hours: number;
  rul_lower_bound_hours: number;
  rul_upper_bound_hours: number;
  risk_level: MachineStatus;
  anomaly_score: number;            // 0.0 - 1.0
  feature_contributions: FeatureContribution[];
  prescriptive_actions: string[];
  latency_ms: number;
  model_version: string;
}

export interface MachineAsset {
  id: string;
  tag: string;
  name: string;
  type: 'Centrifugal Pump' | 'CNC Spindle' | 'Hydraulic Press' | 'Gas Compressor';
  location: string;
  installed_date: string;
  operating_hours: number;
  status: MachineStatus;
  health_index: number;
  current_readings: SensorReading;
  telemetry_history: SensorReading[];
  latest_prediction?: PredictionResponse;
  active_fault?: string | null;
  component_health: {
    bearings: number;
    hydraulic_seals: number;
    cooling_jacket: number;
    drive_shaft: number;
  };
}

export interface ModelMetrics {
  version: string;
  algorithm: string;
  trained_at: string;
  dataset_size: number;
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  roc_auc: number;
  inference_latency_avg_ms: number;
  confusion_matrix: {
    classes: string[];
    matrix: number[][]; // [actual][predicted]
  };
  roc_curve: {
    fpr: number[];
    tpr: number[];
  };
  feature_importance: {
    feature: string;
    label: string;
    importance: number;
  }[];
  loss_history: {
    epoch: number;
    train_loss: number;
    val_loss: number;
  }[];
}

export interface WorkOrder {
  id: string;
  work_order_num: string;
  machine_id: string;
  machine_tag: string;
  machine_name: string;
  failure_mode: FailureMode;
  priority: 'CRITICAL' | 'URGENT' | 'ROUTINE';
  status: 'OPEN' | 'IN_PROGRESS' | 'DISPATCHED' | 'RESOLVED';
  created_at: string;
  predicted_rul_hours: number;
  target_component: string;
  recommended_action: string;
  parts_required: string[];
  assigned_technician?: string;
  estimated_downtime_hours: number;
}
