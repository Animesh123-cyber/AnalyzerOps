import { MachineAsset, SensorReading, WorkOrder } from '../types/telemetry';
import { predictMachineState } from '../services/mlEngine';

export const INITIAL_MACHINES: MachineAsset[] = [
  {
    id: 'EQ-101',
    tag: 'PUMP-SLURRY-04',
    name: 'Centrifugal Slurry Pump #04',
    type: 'Centrifugal Pump',
    location: 'Fluid Transfer Bay B, Line 3',
    installed_date: '2023-04-12',
    operating_hours: 6840,
    status: 'NOMINAL',
    health_index: 96,
    current_readings: {
      timestamp: new Date().toISOString(),
      temperature_bearing: 51.8,
      temperature_ambient: 23.5,
      vibration_rms: 1.54,
      vibration_peak: 2.32,
      vibration_kurtosis: 3.02,
      pressure_hydraulic: 151.5,
      pressure_variance: 0.78,
      rotational_speed: 1780,
      motor_torque: 41.2,
      acoustic_emission: 43.5,
    },
    telemetry_history: generateInitialHistory({
      base_temp: 51.5,
      base_rms: 1.52,
      base_pressure: 152.0,
      base_rpm: 1780,
    }),
    component_health: {
      bearings: 97,
      hydraulic_seals: 94,
      cooling_jacket: 98,
      drive_shaft: 95,
    },
  },
  {
    id: 'EQ-204',
    tag: 'CNC-SPINDLE-12',
    name: 'CNC 5-Axis Milling Spindle #12',
    type: 'CNC Spindle',
    location: 'High-Precision Machining Cell A',
    installed_date: '2022-11-05',
    operating_hours: 8420,
    status: 'MONITOR',
    health_index: 78,
    current_readings: {
      timestamp: new Date().toISOString(),
      temperature_bearing: 63.4,
      temperature_ambient: 24.1,
      vibration_rms: 2.85,
      vibration_peak: 4.60,
      vibration_kurtosis: 4.85, // developing micro-pitting in bearing raceway
      pressure_hydraulic: 148.0,
      pressure_variance: 1.15,
      rotational_speed: 3150,
      motor_torque: 46.5,
      acoustic_emission: 58.2,
    },
    telemetry_history: generateInitialHistory({
      base_temp: 61.0,
      base_rms: 2.65,
      base_pressure: 149.0,
      base_rpm: 3150,
      trend_stress: 0.08,
    }),
    component_health: {
      bearings: 72,
      hydraulic_seals: 88,
      cooling_jacket: 85,
      drive_shaft: 89,
    },
  },
  {
    id: 'EQ-308',
    tag: 'HYD-PRESS-02',
    name: 'Heavy Hydraulic Press #02',
    type: 'Hydraulic Press',
    location: 'Deep Drawing Stamping Wing C',
    installed_date: '2021-08-20',
    operating_hours: 11250,
    status: 'NOMINAL',
    health_index: 91,
    current_readings: {
      timestamp: new Date().toISOString(),
      temperature_bearing: 54.2,
      temperature_ambient: 25.0,
      vibration_rms: 1.82,
      vibration_peak: 2.70,
      vibration_kurtosis: 3.12,
      pressure_hydraulic: 154.2,
      pressure_variance: 0.92,
      rotational_speed: 1240,
      motor_torque: 58.0,
      acoustic_emission: 46.0,
    },
    telemetry_history: generateInitialHistory({
      base_temp: 53.5,
      base_rms: 1.80,
      base_pressure: 154.0,
      base_rpm: 1240,
    }),
    component_health: {
      bearings: 92,
      hydraulic_seals: 87,
      cooling_jacket: 94,
      drive_shaft: 93,
    },
  },
  {
    id: 'EQ-415',
    tag: 'COMP-TURBINE-07',
    name: 'Industrial Gas Compressor #07',
    type: 'Gas Compressor',
    location: 'Refrigerant & Gas Compression Plant',
    installed_date: '2023-01-18',
    operating_hours: 7310,
    status: 'NOMINAL',
    health_index: 89,
    current_readings: {
      timestamp: new Date().toISOString(),
      temperature_bearing: 58.2,
      temperature_ambient: 24.8,
      vibration_rms: 2.05,
      vibration_peak: 3.10,
      vibration_kurtosis: 3.25,
      pressure_hydraulic: 153.8,
      pressure_variance: 0.98,
      rotational_speed: 2940,
      motor_torque: 44.8,
      acoustic_emission: 48.5,
    },
    telemetry_history: generateInitialHistory({
      base_temp: 57.0,
      base_rms: 2.0,
      base_pressure: 153.0,
      base_rpm: 2940,
    }),
    component_health: {
      bearings: 88,
      hydraulic_seals: 91,
      cooling_jacket: 89,
      drive_shaft: 90,
    },
  },
];

// Attach initial prediction state to each machine
for (const m of INITIAL_MACHINES) {
  m.latest_prediction = predictMachineState(m.current_readings, m.id);
  m.health_index = m.latest_prediction.health_index;
  m.status = m.latest_prediction.risk_level;
}

function generateInitialHistory(cfg: {
  base_temp: number;
  base_rms: number;
  base_pressure: number;
  base_rpm: number;
  trend_stress?: number;
}): SensorReading[] {
  const history: SensorReading[] = [];
  const count = 30;
  const now = Date.now();

  for (let i = count; i >= 0; i--) {
    const timeOffset = i * 2000;
    const progress = (count - i) / count;
    const stress = (cfg.trend_stress || 0) * progress * 8;

    history.push({
      timestamp: new Date(now - timeOffset).toISOString(),
      temperature_bearing: parseFloat((cfg.base_temp + (Math.sin(i * 0.4) * 0.8) + stress * 0.8).toFixed(1)),
      temperature_ambient: 24.0 + parseFloat((Math.cos(i * 0.2) * 0.4).toFixed(1)),
      vibration_rms: parseFloat((cfg.base_rms + (Math.sin(i * 0.6) * 0.15) + stress * 0.12).toFixed(2)),
      vibration_peak: parseFloat((cfg.base_rms * 1.5 + (Math.cos(i * 0.5) * 0.25) + stress * 0.2).toFixed(2)),
      vibration_kurtosis: parseFloat((3.05 + (Math.sin(i * 0.3) * 0.2) + stress * 0.22).toFixed(2)),
      pressure_hydraulic: parseFloat((cfg.base_pressure + (Math.cos(i * 0.5) * 1.2) - stress * 0.5).toFixed(1)),
      pressure_variance: parseFloat((0.85 + (Math.sin(i * 0.7) * 0.12) + stress * 0.08).toFixed(2)),
      rotational_speed: Math.round(cfg.base_rpm + (Math.sin(i * 0.5) * 15)),
      motor_torque: parseFloat((42.0 + (Math.cos(i * 0.4) * 1.5) + stress * 0.6).toFixed(1)),
      acoustic_emission: parseFloat((44.0 + (Math.sin(i * 0.5) * 1.8) + stress * 1.2).toFixed(1)),
    });
  }

  return history;
}

export const INITIAL_WORK_ORDERS: WorkOrder[] = [
  {
    id: 'wo-8041',
    work_order_num: 'WO-2026-8041',
    machine_id: 'EQ-204',
    machine_tag: 'CNC-SPINDLE-12',
    machine_name: 'CNC 5-Axis Milling Spindle #12',
    failure_mode: 'BEARING_DEGRADATION',
    priority: 'URGENT',
    status: 'OPEN',
    created_at: '2026-10-05T14:12:00Z',
    predicted_rul_hours: 320,
    target_component: 'Front Spindle Angular Contact Bearing Set (SKF 7014 CD/P4A)',
    recommended_action: 'High kurtosis (4.85) indicates initial raceway micro-pitting. Schedule laser vibrometry inspection and stage replacement ceramic hybrid bearing cartridge prior to cycle 300.',
    parts_required: ['SKF 7014 CD/P4A Preloaded Set', 'Kluber NBU 15 High-Speed Grease', 'Front Labyrinth O-Ring'],
    assigned_technician: 'Marcus Vance (Senior Reliability Eng)',
    estimated_downtime_hours: 3.5,
  },
  {
    id: 'wo-7992',
    work_order_num: 'WO-2026-7992',
    machine_id: 'EQ-308',
    machine_tag: 'HYD-PRESS-02',
    machine_name: 'Heavy Hydraulic Press #02',
    failure_mode: 'CAVITATION_PRESSURE_LOSS',
    priority: 'ROUTINE',
    status: 'RESOLVED',
    created_at: '2026-09-28T09:40:00Z',
    predicted_rul_hours: 840,
    target_component: 'Hydraulic Proportional Relief Valve & Suction Strainer',
    recommended_action: 'Suction line strainer inspected and backflushed. Replaced hydraulic fluid filter element and purged air lock.',
    parts_required: ['Parker 10Q Microglass Filter Element', 'Viton Flange Gaskets'],
    assigned_technician: 'Elena Rostova (Fluid Power Specialist)',
    estimated_downtime_hours: 1.8,
  },
];
