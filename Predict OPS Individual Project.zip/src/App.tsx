import React, { useState, useEffect, useRef } from 'react';
import { TopNav, ActiveTab } from './components/TopNav';
import { FleetOverview } from './components/FleetOverview';
import { ManualDataEntry } from './components/ManualDataEntry';
import { LiveTelemetryStream } from './components/LiveTelemetryStream';
import { ModelStudio } from './components/ModelStudio';
import { ApiWorkbench } from './components/ApiWorkbench';
import { WorkOrdersView } from './components/WorkOrdersView';
import { FaultStressModal } from './components/FaultStressModal';
import { INITIAL_MACHINES, INITIAL_WORK_ORDERS } from './data/initialMachines';
import { DEFAULT_MODEL_METRICS, predictMachineState } from './services/mlEngine';
import { MachineAsset, ModelMetrics, WorkOrder, SensorReading } from './types/telemetry';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('fleet');
  const [machines, setMachines] = useState<MachineAsset[]>(INITIAL_MACHINES);
  const [selectedMachineId, setSelectedMachineId] = useState<string>('EQ-204');
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(INITIAL_WORK_ORDERS);
  const [metrics, setMetrics] = useState<ModelMetrics>(DEFAULT_MODEL_METRICS);
  const [isStreaming, setIsStreaming] = useState<boolean>(true);
  const [isStressModalOpen, setIsStressModalOpen] = useState<boolean>(false);

  // Buffer state to pass to API Workbench when user clicks "Inspect API"
  const [apiPresetMachine, setApiPresetMachine] = useState<MachineAsset | null>(null);

  // Background Telemetry Simulation Loop (1.5s interval)
  useEffect(() => {
    if (!isStreaming) return;

    const interval = setInterval(() => {
      setMachines(prevMachines => {
        return prevMachines.map(machine => {
          const current = machine.current_readings;
          const isFaulty = !!machine.active_fault;

          // Generate micro-variations
          const noise = (Math.random() - 0.5);
          let newVib = Math.max(current.vibration_rms + noise * 0.08, 0.6);
          let newPeak = newVib * (1.4 + Math.random() * 0.3);
          let newKurt = Math.max(current.vibration_kurtosis + noise * 0.12, 2.7);
          let newTemp = Math.max(current.temperature_bearing + noise * 0.2, 38);
          let newPress = Math.max(current.pressure_hydraulic + noise * 0.6, 60);
          let newPressVar = Math.max(current.pressure_variance + noise * 0.05, 0.2);
          let newTorque = Math.max(current.motor_torque + noise * 0.3, 20);
          let newAcoustic = Math.max(current.acoustic_emission + noise * 0.4, 35);

          // Apply fault bias if active
          if (machine.active_fault === 'bearing') {
            newVib = Math.min(newVib + 0.15, 6.2);
            newKurt = Math.min(newKurt + 0.25, 7.8);
            newPeak = newVib * 1.85;
            newAcoustic = Math.min(newAcoustic + 0.6, 76);
          } else if (machine.active_fault === 'thermal') {
            newTemp = Math.min(newTemp + 0.6, 88.5);
          } else if (machine.active_fault === 'cavitation') {
            newPress = Math.max(newPress - 1.2, 98);
            newPressVar = Math.min(newPressVar + 0.35, 7.5);
          } else if (machine.active_fault === 'overstrain') {
            newTorque = Math.min(newTorque + 1.2, 89);
          }

          const updatedReading: SensorReading = {
            timestamp: new Date().toISOString(),
            temperature_bearing: parseFloat(newTemp.toFixed(1)),
            temperature_ambient: parseFloat((24.0 + Math.sin(Date.now() / 10000) * 0.8).toFixed(1)),
            vibration_rms: parseFloat(newVib.toFixed(2)),
            vibration_peak: parseFloat(newPeak.toFixed(2)),
            vibration_kurtosis: parseFloat(newKurt.toFixed(2)),
            pressure_hydraulic: parseFloat(newPress.toFixed(1)),
            pressure_variance: parseFloat(newPressVar.toFixed(2)),
            rotational_speed: current.rotational_speed,
            motor_torque: parseFloat(newTorque.toFixed(1)),
            acoustic_emission: parseFloat(newAcoustic.toFixed(1)),
          };

          // Re-evaluate ML prediction
          const prediction = predictMachineState(updatedReading, machine.id);

          // Append to history (keep last 30 readings)
          const newHistory = [...machine.telemetry_history.slice(-29), updatedReading];

          // Degradation of component health if prediction is critical or warning
          const compHealth = { ...machine.component_health };
          if (prediction.failure_mode === 'BEARING_DEGRADATION') {
            compHealth.bearings = Math.max(compHealth.bearings - 1, 24);
          } else if (prediction.failure_mode === 'HEAT_DISSIPATION_FAILURE') {
            compHealth.cooling_jacket = Math.max(compHealth.cooling_jacket - 1, 28);
          } else if (prediction.failure_mode === 'CAVITATION_PRESSURE_LOSS') {
            compHealth.hydraulic_seals = Math.max(compHealth.hydraulic_seals - 1, 30);
          }

          return {
            ...machine,
            current_readings: updatedReading,
            telemetry_history: newHistory,
            latest_prediction: prediction,
            health_index: prediction.health_index,
            status: prediction.risk_level,
            component_health: compHealth,
          };
        });
      });
    }, 1500);

    return () => clearInterval(interval);
  }, [isStreaming]);

  // Check for critical thresholds and create work orders automatically if not already present
  useEffect(() => {
    machines.forEach(m => {
      if (m.status === 'CRITICAL' || m.status === 'WARNING') {
        setWorkOrders(prev => {
          const exists = prev.some(o => o.machine_id === m.id && o.status !== 'RESOLVED');
          if (!exists && m.latest_prediction) {
            const newOrder: WorkOrder = {
              id: `wo-${Date.now()}`,
              work_order_num: `WO-2026-${Math.floor(1000 + Math.random() * 9000)}`,
              machine_id: m.id,
              machine_tag: m.tag,
              machine_name: m.name,
              failure_mode: m.latest_prediction.failure_mode,
              priority: m.status === 'CRITICAL' ? 'CRITICAL' : 'URGENT',
              status: 'OPEN',
              created_at: new Date().toISOString(),
              predicted_rul_hours: m.latest_prediction.remaining_useful_life_hours,
              target_component: m.latest_prediction.failure_mode === 'BEARING_DEGRADATION' 
                ? 'High-Speed Precision Bearing Assembly'
                : m.latest_prediction.failure_mode === 'HEAT_DISSIPATION_FAILURE'
                ? 'Cooling Heat Exchanger Jacket'
                : 'Hydraulic Proportional Line & Strainer',
              recommended_action: m.latest_prediction.prescriptive_actions[0] || 'Schedule immediate engineering inspection.',
              parts_required: ['OEM Seal Kit', 'ISO VG 46 Fluid / Grease', 'Replacement Assembly'],
              estimated_downtime_hours: m.status === 'CRITICAL' ? 4.5 : 2.0,
            };
            return [newOrder, ...prev];
          }
          return prev;
        });
      }
    });
  }, [machines]);

  const handleInjectFault = (machineId: string, faultType: string) => {
    setMachines(prev => prev.map(m => {
      if (m.id !== machineId) return m;

      const updated = { ...m, active_fault: faultType };
      const cur = { ...m.current_readings };

      if (faultType === 'bearing') {
        cur.vibration_rms = 4.8;
        cur.vibration_kurtosis = 6.4;
        cur.vibration_peak = 7.8;
        cur.acoustic_emission = 74.0;
      } else if (faultType === 'thermal') {
        cur.temperature_bearing = 85.0;
      } else if (faultType === 'cavitation') {
        cur.pressure_hydraulic = 105.0;
        cur.pressure_variance = 6.2;
      } else if (faultType === 'overstrain') {
        cur.motor_torque = 86.0;
      }

      updated.current_readings = cur;
      updated.latest_prediction = predictMachineState(cur, m.id);
      updated.health_index = updated.latest_prediction.health_index;
      updated.status = updated.latest_prediction.risk_level;
      return updated;
    }));
  };

  const handleResetFault = (machineId: string) => {
    setMachines(prev => prev.map(m => {
      if (m.id !== machineId) return m;

      const resetReadings: SensorReading = {
        timestamp: new Date().toISOString(),
        temperature_bearing: 52.0,
        temperature_ambient: 24.0,
        vibration_rms: 1.6,
        vibration_peak: 2.4,
        vibration_kurtosis: 3.05,
        pressure_hydraulic: 152.0,
        pressure_variance: 0.85,
        rotational_speed: m.current_readings.rotational_speed,
        motor_torque: 42.0,
        acoustic_emission: 44.0,
      };

      const pred = predictMachineState(resetReadings, m.id);
      return {
        ...m,
        active_fault: null,
        current_readings: resetReadings,
        latest_prediction: pred,
        health_index: pred.health_index,
        status: pred.risk_level,
      };
    }));
  };

  const handleDispatchOrder = (orderId: string, techName: string) => {
    setWorkOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'DISPATCHED',
          assigned_technician: techName,
        };
      }
      return o;
    }));
  };

  const handleResolveOrder = (orderId: string) => {
    const order = workOrders.find(o => o.id === orderId);
    if (order) {
      handleResetFault(order.machine_id);
    }
    setWorkOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return { ...o, status: 'RESOLVED' };
      }
      return o;
    }));
  };

  const handleOpenApiForMachine = (machine: MachineAsset) => {
    setApiPresetMachine(machine);
    setSelectedMachineId(machine.id);
    setActiveTab('api');
  };

  const handleUpdateMachineTelemetry = (machineId: string, reading: SensorReading) => {
    setMachines(prev => prev.map(m => {
      if (m.id !== machineId) return m;
      const pred = predictMachineState(reading, m.id);
      return {
        ...m,
        current_readings: reading,
        telemetry_history: [...m.telemetry_history.slice(-29), reading],
        latest_prediction: pred,
        health_index: pred.health_index,
        status: pred.risk_level,
      };
    }));
  };

  const handleAddMachine = (newMachine: MachineAsset) => {
    setMachines(prev => [newMachine, ...prev]);
  };

  const handleBatchTelemetryImport = (machineId: string, readings: SensorReading[]) => {
    if (readings.length === 0) return;
    const latest = readings[readings.length - 1];
    setMachines(prev => prev.map(m => {
      if (m.id !== machineId) return m;
      const pred = predictMachineState(latest, m.id);
      return {
        ...m,
        current_readings: latest,
        telemetry_history: [...m.telemetry_history, ...readings].slice(-30),
        latest_prediction: pred,
        health_index: pred.health_index,
        status: pred.risk_level,
      };
    }));
  };

  const handleNavigateToDataEntry = (machineId: string) => {
    setSelectedMachineId(machineId);
    setActiveTab('entry');
  };

  const handleNavigateToTelemetry = (machineId: string) => {
    setSelectedMachineId(machineId);
    setActiveTab('telemetry');
  };

  const criticalOrdersCount = workOrders.filter(o => o.status === 'OPEN').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* 3-Zone Top Navigation Contract */}
      <TopNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        criticalCount={criticalOrdersCount}
        openStressModal={() => setIsStressModalOpen(true)}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 py-6">
        {activeTab === 'fleet' && (
          <FleetOverview
            machines={machines}
            selectedMachineId={selectedMachineId}
            onSelectMachine={setSelectedMachineId}
            onInjectFault={handleInjectFault}
            onResetFault={handleResetFault}
            onOpenApiForMachine={handleOpenApiForMachine}
            onNavigateToTelemetry={handleNavigateToTelemetry}
            onNavigateToDataEntry={handleNavigateToDataEntry}
          />
        )}

        {activeTab === 'entry' && (
          <ManualDataEntry
            machines={machines}
            selectedMachineId={selectedMachineId}
            onSelectMachine={setSelectedMachineId}
            onUpdateMachineTelemetry={handleUpdateMachineTelemetry}
            onAddMachine={handleAddMachine}
            onBatchTelemetryImport={handleBatchTelemetryImport}
          />
        )}

        {activeTab === 'telemetry' && (
          <LiveTelemetryStream
            machines={machines}
            selectedMachineId={selectedMachineId}
            onSelectMachine={setSelectedMachineId}
            isStreaming={isStreaming}
            setIsStreaming={setIsStreaming}
            onInjectFault={handleInjectFault}
            onResetFault={handleResetFault}
            onNavigateToDataEntry={handleNavigateToDataEntry}
          />
        )}

        {activeTab === 'studio' && (
          <ModelStudio
            metrics={metrics}
            onMetricsUpdate={setMetrics}
          />
        )}

        {activeTab === 'api' && (
          <ApiWorkbench
            initialReading={apiPresetMachine?.current_readings}
            initialMachineId={apiPresetMachine?.id || selectedMachineId}
          />
        )}

        {activeTab === 'orders' && (
          <WorkOrdersView
            workOrders={workOrders}
            onDispatchOrder={handleDispatchOrder}
            onResolveOrder={handleResolveOrder}
          />
        )}
      </main>

      {/* Clean quiet footer adhering to anti-slop rules: no mechanical fake tickers */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-4 sm:px-6 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            ApexPredict Industrial Machine Learning System · ISO 10816 Condition-Based Maintenance
          </div>
          <div className="flex items-center gap-3">
            <span>FastAPI 0.110</span>
            <span aria-hidden="true">·</span>
            <span>XGBoost 2.0.3</span>
            <span aria-hidden="true">·</span>
            <span>Scikit-Learn 1.4</span>
          </div>
        </div>
      </footer>

      {/* Fault Injection Simulation Modal */}
      <FaultStressModal
        isOpen={isStressModalOpen}
        onClose={() => setIsStressModalOpen(false)}
        machines={machines}
        selectedMachineId={selectedMachineId}
        setSelectedMachineId={setSelectedMachineId}
        onInjectFault={handleInjectFault}
        onResetFault={handleResetFault}
      />
    </div>
  );
}
