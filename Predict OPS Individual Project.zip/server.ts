import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { predictMachineState, DEFAULT_MODEL_METRICS } from './src/services/mlEngine';
import { SensorReading } from './src/types/telemetry';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Health check endpoint
  app.get('/api/v1/health', (req, res) => {
    res.json({
      status: 'healthy',
      service: 'ApexPredict Predictive Maintenance API',
      version: '2.4.1',
      model_version: 'v2.4.1-xgboost-ensemble',
      timestamp: new Date().toISOString(),
    });
  });

  // Model performance metrics endpoint
  app.get('/api/v1/model/metrics', (req, res) => {
    res.json(DEFAULT_MODEL_METRICS);
  });

  // Core Real-Time Prediction Endpoint
  app.post('/api/v1/predict', (req, res) => {
    try {
      const data = req.body;
      const machineId = data.machine_id || 'ASSET-API-01';

      const reading: SensorReading = {
        timestamp: new Date().toISOString(),
        temperature_bearing: Number(data.temperature_bearing ?? 52.4),
        temperature_ambient: Number(data.temperature_ambient ?? 24.2),
        vibration_rms: Number(data.vibration_rms ?? 1.65),
        vibration_peak: Number(data.vibration_peak ?? 2.45),
        vibration_kurtosis: Number(data.vibration_kurtosis ?? 3.05),
        pressure_hydraulic: Number(data.pressure_hydraulic ?? 152.0),
        pressure_variance: Number(data.pressure_variance ?? 0.85),
        rotational_speed: Number(data.rotational_speed ?? 2450),
        motor_torque: Number(data.motor_torque ?? 42.5),
        acoustic_emission: Number(data.acoustic_emission ?? 44.0),
      };

      const prediction = predictMachineState(reading, machineId);
      res.json(prediction);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Invalid sensor payload' });
    }
  });

  // Batch Prediction Endpoint
  app.post('/api/v1/batch-predict', (req, res) => {
    try {
      const items: any[] = req.body.items || [];
      const results = items.map((data, index) => {
        const machineId = data.machine_id || `BATCH-${index + 1}`;
        const reading: SensorReading = {
          timestamp: new Date().toISOString(),
          temperature_bearing: Number(data.temperature_bearing ?? 52.4),
          temperature_ambient: Number(data.temperature_ambient ?? 24.2),
          vibration_rms: Number(data.vibration_rms ?? 1.65),
          vibration_peak: Number(data.vibration_peak ?? 2.45),
          vibration_kurtosis: Number(data.vibration_kurtosis ?? 3.05),
          pressure_hydraulic: Number(data.pressure_hydraulic ?? 152.0),
          pressure_variance: Number(data.pressure_variance ?? 0.85),
          rotational_speed: Number(data.rotational_speed ?? 2450),
          motor_torque: Number(data.motor_torque ?? 42.5),
          acoustic_emission: Number(data.acoustic_emission ?? 44.0),
        };
        return predictMachineState(reading, machineId);
      });
      res.json({ count: results.length, predictions: results });
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Batch prediction failed' });
    }
  });

  // OpenAPI 3.1 specification schema
  app.get('/api/v1/openapi.json', (req, res) => {
    res.json({
      openapi: '3.1.0',
      info: {
        title: 'ApexPredict Predictive Maintenance API',
        version: '2.4.1',
        description: 'End-to-end industrial IoT telemetry ingestion & ML failure prediction service.',
      },
      paths: {
        '/api/v1/predict': {
          post: {
            summary: 'Predict machinery failure state & RUL',
            requestBody: {
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['vibration_rms', 'temperature_bearing'],
                    properties: {
                      machine_id: { type: 'string' },
                      temperature_bearing: { type: 'number' },
                      temperature_ambient: { type: 'number' },
                      vibration_rms: { type: 'number' },
                      vibration_peak: { type: 'number' },
                      vibration_kurtosis: { type: 'number' },
                      pressure_hydraulic: { type: 'number' },
                      pressure_variance: { type: 'number' },
                      rotational_speed: { type: 'number' },
                      motor_torque: { type: 'number' },
                      acoustic_emission: { type: 'number' },
                    },
                  },
                },
              },
            },
            responses: {
              '200': { description: 'Prediction result with failure probability and RUL' },
            },
          },
        },
      },
    });
  });

  // Mount Vite middleware in development or static dist in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ApexPredict Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
